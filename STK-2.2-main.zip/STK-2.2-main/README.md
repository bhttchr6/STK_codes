# STK-2.2
Run *main_rev.m* and it will generate the STK knot designs.<br>
Change number of elements by changing *n_var* at line 5.<br>
save the curve as excel sheet using line 15. <br>
Plot using line 28
