function main_rev
clear all
close all
clc
n_var = 12;
grav_fac_1 = 1.0;
curve_grav = STK_code(grav_fac_1, n_var);

grav_fac_2 = 0.0;
[curve_norm, x_norm] = STK_code(grav_fac_2, n_var);
%check_coll(x_norm);

%%% save your curve to excel file
T = array2table(curve_norm);
writetable(T,'STK.txt');

nPoints = n_var+1;
[~, curve_ideal, curve_ideal_full] = ideal_knot(nPoints);
curve_ideal(3,:) = curve_ideal(3,:)*0.3601;

curve_flip(1,:) = -curve_ideal(1,:); % mirror about x
curve_flip(2,:) = curve_ideal(2,:);  % mirror about y
curve_flip(3,:) = -curve_ideal(3,:);

curve_ideal_full = [fliplr(curve_flip) curve_ideal];


tubeplot_full_multiple(curve_grav',curve_norm',curve_norm', 1, 8, 1/2);daspect([1,1,1]);% camlight;
%tubeplot_full_multiple(curve_norm', curve_norm',curve_ideal_full, 1, 8, 1/2);daspect([1,1,1]);
end