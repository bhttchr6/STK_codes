
function [knot , x]= STK_code(gravity_fac, n_var)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       Code for generating self-tying knot %
%      Code to generate a self-tying knot design with gravity considerations
% capping the maximum length of the half domain to 120 cm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%clear all
%close all
%clc
global video
%x=[1  5 5 6];

% video = VideoWriter('knot.avi'); %create the video object
% video.FrameRate = 20;
% video.Quality = 100;    % Default 75
% open(video);
rng default
global fac x0 y0 z0 L theta_twist x_mid y_mid z_mid x_mid_2 y_mid_2 z_mid_2 nel theta_bend coord_tip coords theta_max ratio Lx bending_angle twisting_angle dist_1 ...
    dist_2 M1 M2_sum X_mid_3 val_delx val_dely val_delz grav_factor
% specify twisting angles
fid =fopen('C:\Users\bhttchr6\Documents\SMP_video\opt_seq.dat', 'w' );
itr=0;
 %n_var = 12;
%for n_var = 10:1:13
%n_var = 10;
% for theta_i = 0:1:25
%n_var = 13; % no. of elements
itr = n_var;%theta_i+1;

theta_twist = 4;
theta_bend = 25;
%      theta_bend = theta_i;

bending_angle = theta_bend;

twisting_angle = theta_twist;

%%%% minimum and maximum distance constraints between the points of curves  
dist_1 = 1.0; dist_2 = 10.0;


%%% Generate Ideal Knot 
nPoints = n_var+1;
[Lknot_ideal, curve_ideal, curve_ideal_full] = ideal_knot(nPoints);


%%% FACTOR THE Z-COORDINATES BY 0.3601
curve_ideal(3,:) = curve_ideal(3,:)*0.3601;

% tubeplot(curve_ideal_full,1, 8, 1/2, itr, 2);daspect([1,1,1]); camlight;

pt_1 = floor((nPoints-1)/2)+1;
mid_cords_ideal = curve_ideal(:,pt_1); % point#1 on the ideal knot around mid point


x_mid = mid_cords_ideal(1); y_mid = mid_cords_ideal(2); z_mid = mid_cords_ideal(3);


coord_tip = curve_ideal(:,end);  % coordinates at the tip
coords = curve_ideal(:,end-1); % coordinate at a point very close to the tip

% specify the total number of elements for the half-domain
numberOfVariables = n_var;

% specify length of each bending and twisting element
L_knot = 120; %cm
L = L_knot/numberOfVariables;


% define the weight factor of the objective function
fac = 5;

% Specify where to have the tip coordinates

% x0 = -14.4801;
% y0 = 6.0013;
% z0 = -5.0148; 

x0 = coord_tip(1);
y0 = coord_tip(2);
z0= coord_tip(3);

ObjectiveFunction = @FK;
%FitnessFunction = @FK;
ConstraintFunction = @constraint;
nel = numberOfVariables;





lb = 1*ones(1,numberOfVariables);
ub = 7*ones(1,numberOfVariables);


%%% Run the geentic algorithm with gravity
% grav_factor = 1.0; %% activate or deactivate gravity
% IntCon = [1:n_var];
% [x,fval, exitval, Output] = ga(ObjectiveFunction,numberOfVariables,[],[],[],[],lb,ub,ConstraintFunction,IntCon);
% %x = [6 1 1 1 1 1 1 1 1 1 1 3];
% %%%% Attach the neutral element (first element) to the STK sequence
% x_grav = [5 x];
% 
% %%% Print knot sequence to screen
% x_grav
% %value = FK(x);
% curve_grav = CJ(x_grav);


%%% Run the geentic algorithm without gravity
grav_factor = gravity_fac; %% activate or deactivate gravity
IntCon = [1:n_var];
[x,fval, exitval, Output] = ga(ObjectiveFunction,numberOfVariables,[],[],[],[],lb,ub,ConstraintFunction,IntCon);
%x = [6 1 1 1 1 1 1 1 1 1 1 3];
%%%% Attach the neutral element (first element) to the STK sequence
x = [5 x];

%%% Print knot sequence to screen
x
%value = FK(x);
knot = CJ(x);



% plot full knot
%tubeplot(curve_norm',1, 8, 1/2, itr, 1);daspect([1,1,1]); camlight;
%end
%tubeplot_full_multiple(curve_grav',curve_norm',curve_ideal_full, 1, 8, 1/2);daspect([1,1,1]);% camlight;
%%% Plot the knot path
%main_animation(x)

fclose(fid);
end

%%% Generate full curve from sequence
function curve_joined = CJ(x)

x1 = [x];
x2 = flip(x);
%fval
original =1;
rotated =0;
[curve_o, ~] = plot_final(x, original, rotated);
[curve_m, ~] = plot_final(x1, original, rotated);
curve_o = [0 0 0;curve_o];
curve_flip = flipud(curve_o);

% specify what kind of mirror you want
curve_flip(:,1) = -curve_flip(:,1); % mirror about x
curve_flip(:,2) = curve_flip(:,2);  % mirror about y
curve_flip(:,3) = -curve_flip(:,3);
curve_joined = [curve_flip;curve_m];
end


%end
%%%% ====== function called by GA==================
function y = FK(x)
global fac x0 y0 z0 L x_mid y_mid z_mid x_mid_2 y_mid_2 z_mid_2 nel coord_tip coords theta_max theta_twist theta_bend ratio Lx X_mid_3 val_delx val_dely val_delz L grav_factor

%%% Attach the neutral element to the sequence to be optimized
seq =[5 x];
R = eye(3,3);
X=[0;0;0];

% theta_bend_max = 25;
% for theta_i = 0:1:theta_bend_max
%     theta_bend = 25;
%     theta_twist = 4;


%%% Run the forward kinematics module
 for i =1:size(seq,2)
%     
     el = seq(i);
  
    [alpha, beta, gamma] = param(el);
    R_x = [1 0          0;
        0 cos(alpha) -sin(alpha);
        0 sin(alpha) cos(alpha)];
    
    R_y = [cos(beta) 0  sin(beta);
        0         1  0
        -sin(beta) 0  cos(beta)];
    
    
    R_z = [cos(gamma) -sin(gamma) 0;
        sin(gamma)  cos(gamma) 0;
        0           0          1];
    
    
    
    if el ==1
        % delta_x = cos(theta_bend*0.0174533)*L; delta_y= sin(theta_bend*0.0174533)*L; delta_z=0;
        delta_x = 0.98*L; delta_y= 0.22*L; delta_z=0;
    end
    if el ==2
        delta_x = 0.98*L ;delta_y= -0.22*L; delta_z=0;
    end
    if el ==3
        delta_x = 0.98*L ;delta_y = 0;delta_z = -0.22*L;
    end
    if el ==4
        delta_x = 0.98*L ;delta_y = 0; delta_z = 0.22*L;
    end
    if el ==5
        delta_x = L;delta_y = 0;delta_z = 0;
    end
    if el ==6
        delta_x = L;delta_y = 0; delta_z = 0;
    end
    if el ==7
        delta_x = L;delta_y = 0; delta_z = 0;
    end
    
    delta_X = R*[delta_x;delta_y;delta_z];
    
    
    P0=X;
    X=X+delta_X;
    
    R_curr = R_z*R_y*R_x;
    
    R = R*R_curr;
    
    P=X;
    %plot_links(P,P0,[],el,0)
    curve(i,:) = X';
end

%%% loop over each element and calculate the stiffness

curve_m = [0 0 0 ;curve];
K = zeros(6*size(curve_m,1), 6*size(curve_m,1));
F = zeros(6*size(curve_m,1),1);
U = zeros(6*size(curve_m,1),1);
for el =1:size(seq,2)
    
    %E = 1.0*10^3;
    E = 100000; %% 100 GPa = 100x1000 MPa
    mu = 0.3;
    G = E/(2*(1+mu));
    %G = 96.52;
    a = 2.0; % 2.0 mm w=h for the sample
    J = a^4/6;
    A = a*a;
    Iy = a^4/12;
    Iz = Iy;
    x1 = curve_m(el,1);y1 = curve_m(el,2);z1 = curve_m(el,3);
    x2 = curve_m(el+1,1);y2 = curve_m(el+1,2);z2 = curve_m(el+1,3);
    k_el = SpaceFrameElementStiffness(E,G,A,Iy,Iz,J,x1,y1,z1,x2,y2,z2);
    i = el; j = el+1;
    K = SpaceFrameAssemble(K,k_el,i,j);
    
    
end
%  F(2:6:6*size(curve_m,1),1)=
nodes = 1:size(seq,2)+1;
nel_el = size(seq,2);
i_val = nodes-1;
i_nodes_y = 2+i_val.*6;
i_nodes_x = 1+i_val.*6;
i_nodes_z = 3+i_val.*6;
rho_SMP = 0.001; % g/mm^3
mass_SMP = rho_SMP*a^2*L; 
g_acc = 9.80665; % in m/s^2
wt_el = g_acc*mass_SMP;
%wt_el = 3.68*10^-4;
val_val = -(nel_el-i_val).*wt_el;
F(i_nodes_y,1) = val_val;
F(i_nodes_y,1) = grav_factor*val_val;
%%% Force value
F(2,1)=0;
U(7:end,1) = K(7:end, 7:end)\F(7:end,1);
Ux = U(i_nodes_x);
Uy = U(i_nodes_y);
Uz = U(i_nodes_z);
Uy = Uy(2:end,1);
Ux = Ux(2:end,1);
Uz = Uz(2:end,1);
curve(:,2) = curve(:,2)+Uy;
curve(:,3) = curve(:,3)+Uz;
curve(:,1) = curve(:,1)+Ux;

% %%%%% Plot the new curve
% curve_o = [0 0 0;curve];
% curve_flip = flipud(curve_o);
% 
% % specify what kind of mirror you want
% curve_flip(:,1) = -curve_flip(:,1); % mirror about x
% curve_flip(:,2) = curve_flip(:,2);  % mirror about y
% curve_flip(:,3) = -curve_flip(:,3);
% curve_joined = [curve_flip;curve_o];
% 
% tubeplot(curve_joined',1, 8, 1/2, 0, 1);daspect([1,1,1]); camlight;

% calculate the mid point of the generated knot
pt_1 = floor(nel/2)+3;
mid_cords_gen = curve(pt_1,:);
x_mid_gen = mid_cords_gen(1);
y_mid_gen = mid_cords_gen(2);
z_mid_gen = mid_cords_gen(3);

% calculate the second control point of the generated knot (if active)
pt_2 = floor(nel/2)-3;
mid_cords_gen_2 = curve(pt_2,:);
x_mid_gen_2 = mid_cords_gen_2(1);
y_mid_gen_2 = mid_cords_gen_2(2);
z_mid_gen_2 = mid_cords_gen_2(3);


% calculate the 3rd control point of the generated knot (if active)
pt_3 = floor(nel/2)+2;
mid_cords_gen_3 = curve(pt_3,:);
x_mid_gen_3 = mid_cords_gen_3(1);
y_mid_gen_3 = mid_cords_gen_3(2);
z_mid_gen_3 = mid_cords_gen_3(3);


% calculate the tip-coordinates of the generated knot
x_tip = P(1);
y_tip = P(2);
z_tip = P(3);

% calculate near tip coordinates
x_ntip = curve(size(seq,2)-1,1);
y_ntip = curve(size(seq,2)-1,2);
z_ntip = curve(size(seq,2)-1,3);

% calculate unit vector for the generated knot

norm_L = sqrt((x_tip-x_ntip)^2+(y_tip-y_ntip)^2+(z_tip-z_ntip)^2 );
L_x = (x_tip-x_ntip)/norm_L; % x-component
L_y = (y_tip-y_ntip)/norm_L; % y-component
L_z = (z_tip-z_ntip)/norm_L; % x-component

% sperical angles for computed knot
sin_phi = L_y; % y-component
cos_phi = L_x; % x-component

% calculate theta
theta = acos(L_z);
if (cos_phi>0 && sin_phi>0)
    phi = asin(L_y); % first quadrant
    %     fprintf("Computed knot in 1st quadrant\n");
end
if (cos_phi<0 && sin_phi>0)
    phi = acos(L_x); % 2nd quadrant
    %     fprintf("Computed knot in 2nd quadrant\n");
end
if (cos_phi<0 && sin_phi<0)
    phi = pi + asin(-L_y);% 3rd quadrant
    %     fprintf("Computed knot in 3rd quadrant\n");
end
if (cos_phi>0 && sin_phi<0)
    phi = 2*pi - asin(-L_y);
    %     fprintf("Ideal knot in 4th quadrant\n");
end
if (sin_phi==0 && cos_phi>0)
    phi = 0;
end
if (sin_phi==0 && cos_phi <0)
    phi = pi;
end
if (cos_phi ==0 && sin_phi>0)
    phi = pi/2;
end
if (cos_phi ==0 && sin_phi<0)
    phi = 3*pi/2;
end
if (cos_phi ==0 && sin_phi==0)
    phi = 0;
end



% calculate the unit vector giving the orientation of the theoritical knot  tip
norm_v = sqrt((coord_tip(1)-coords(1))^2+(coord_tip(2)-coords(2))^2+(coord_tip(3)-coords(3))^2 );
v_x = (coord_tip(1)-coords(1))/norm_v; % x-component
v_y = (coord_tip(2)-coords(2))/norm_v; % y-component
v_z = (coord_tip(3)-coords(3))/norm_v; % x-component


%=====================================================================
% sperical angles for ideal knot
sin_phi_ideal = v_y; % y-component
cos_phi_ideal = v_x; % x-component
if (cos_phi_ideal>0 && sin_phi_ideal>0)
    phi_ideal = asin(v_y); % first quadrant
    %     fprintf("Ideal knot in 1st quadrant\n");
end
if (cos_phi_ideal<0 && sin_phi_ideal>0)
    phi_ideal = acos(v_x); % 2nd quadrant
    %     fprintf("Ideal knot in 2nd quadrant\n");
end
if (cos_phi_ideal<0 && sin_phi_ideal<0)
    phi_ideal = pi + asin(-v_y);% 3rd quadrant
    %     fprintf("Ideal knot in 3rd quadrant\n");
end
if (cos_phi_ideal>0 && sin_phi_ideal<0)
    phi_ideal = 2*pi - asin(-v_y);
    %     fprintf("Ideal knot in 4th quadrant\n");
end

phi_ideal;
theta_ideal = acos(v_z);


%=====================================================================

% calculate error in coordinates
term_1 = (x0-x_tip)^2+(y0-y_tip)^2+(z0-z_tip)^2;
term_2 = (x_mid-x_mid_gen)^2+(y_mid-y_mid_gen)^2+(z_mid-z_mid_gen)^2;
% term_3 = (x_mid_2-x_mid_gen_2)^2+(y_mid_2-y_mid_gen_2)^2+(z_mid_2-z_mid_gen_2)^2;
% term_4 = (X_mid_3(1,1)-x_mid_gen_3)^2+(X_mid_3(2,1)-y_mid_gen_2)^2+(X_mid_3(3,1)-z_mid_gen_2)^2;
w_mid = 5;   % mid point coordinates
w_mid_2 = 0; % mid + towards the tip
w_mid_3 = 0; % mid  - towards the base

p_error = sqrt( term_1+ w_mid*term_2);

% calculate error in orientation
q_error = sqrt((phi_ideal-phi)^2+(theta_ideal-theta)^2);


y = obj_cal(p_error, q_error,fac);


% fprintf('===============================\n')
% fprintf('phi ideal knot = %f\n', phi_ideal*180/pi)
% fprintf('theta ideal knot = %f\n', theta_ideal*180/pi)
%
% fprintf('===============================\n')
% fprintf('phi = %f\n', phi*180/pi)
% fprintf('theta = %f\n', theta*180/pi)
%
% fprintf('===============================\n')
% fprintf('P_error = %f\n', p_error)
% fprintf('Q_error = %f\n', q_error)



end
%end



%=========== define the constraint function================


function [c, ceq] = constraint(x)
global L  bending_angle twisting_angle dist_1 dist_2 M1 M2_sum

const_case = 1;

if const_case == 1
    
    % calculate the final configuration distances
    original = 1;
    rotated = 0;
    [curve_o, ~] = plot_final(x, original, rotated);
    %[curve_m, ~] = plot_final(x1, original, rotated);
    curve_m = curve_o;
    curve_o = [0 0 0;curve_o];
    %tubeplot(curve_o',2, 8, 1/2, 1, 2);daspect([1,1,1]); camlight;
    
    
    %Interpolate the curve
    n = 20;
    ctr = 0;
    for i =1:size(curve_o,1)-1
        
        P1 = curve_o(i,:);
        P2 = curve_o(i+1,:);
        
        t = linspace(0,1,n)';
        P_inb = (1-t)*P1 + t*P2;
        P_inb = P_inb(2:end,:);
        if i==1
            j=0;
        end
        %     n*ctr+j:(ctr+1)*n-1
        %ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1)
        curve_inp(ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1),:) = P_inb;
        
        ctr = ctr+1;
        j=0;
    end
    
    
    
    % curve_flip = flipud(curve_o);
    
    % add the origin of the interpolated curve
    curve_inp = [0 0 0; curve_inp];
    curve_flip_inp = flipud(curve_inp);
    
    
    % specify what kind of mirror you want
    % curve_flip(:,1) = -curve_flip(:,1); % mirror about x
    % curve_flip(:,2) = curve_flip(:,2);  % mirror about y
    % curve_flip(:,3) = -curve_flip(:,3);
    
    
    % mirror the interpolated curve
    curve_flip_inp(:,1) = -curve_flip_inp(:,1); % mirror about x
    curve_flip_inp(:,2) = curve_flip_inp(:,2);  % mirror about y
    curve_flip_inp(:,3) = -curve_flip_inp(:,3);
    
    %%% Generate the whole knot
    %curve_joined = [curve_flip;curve_m]; % the whole knot
    
    %%% calculate distance
    % dmat1 = distmat(curve_flip, curve_o);
    % dmat1(end,1) = 10000000;
    
    % distance of interpolated curve
    n = size(curve_inp,1);
    n= ceil(n/2);
    dmat1 = distmat(curve_flip_inp(1:n,:), curve_inp(n:end,:));
    % dmat1 = distmat(curve_flip_inp, curve_inp);
    dmat1(end,1) = 10000000;
    % M1 = min(dmat1, [], 'all');
    
    
    
    M1 = min(dmat1, [], 'all');
    %c1 = [0.0001 - M1];
    %ceq = [];
    
    %=================================================================
    collision = 0;
    if collision ==1
        seq = x;
        
        
        % check collision for each angle of bending
        theta_bend_max = bending_angle;
        sign = bending_angle/abs(bending_angle);
        theta_ctr = 0;
        
        n_angles = 28;
        thetas = linspace(0, theta_bend_max, n_angles);
        min_theta_val = zeros(length(thetas),1);
        for i = 1:size(thetas,2)
            theta_bend = thetas(i);
            theta_twist = twisting_angle;
            [curve_o] = geometry(seq, theta_bend, theta_twist);
            curve = [0 0 0;curve_o];
            
            % generate the interpolated curve
            ctr = 0;
            n = 2;
            for j =1:size(curve,1)-1
                
                P1 = curve(j,:);
                P2 = curve(j+1,:);
                
                t = linspace(0,1,n)';
                P_inb = (1-t)*P1 + t*P2;
                P_inb = P_inb(2:end,:);
                if i==1
                    k=0;
                end
                %     n*ctr+j:(ctr+1)*n-1
                %ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1)
                curve_inp_i(ctr*n+k-(ctr-1):(ctr+1)*n-(ctr+1),:) = P_inb;
                
                ctr = ctr+1;
                k=0;
            end
            curve_inp_i = [0 0 0;curve_inp_i];
            
            curve_inp_i_flip = flipud(curve_inp_i);
            
            % specify what kind of mirror you want
            curve_inp_i_flip(:,1) = -curve_inp_i_flip(:,1); % mirror about x
            curve_inp_i_flip(:,2) = curve_inp_i_flip(:,2);  % mirror about y
            curve_inp_i_flip(:,3) = -curve_inp_i_flip(:,3);
            
            
            dmat2 = distmat(curve_inp_i_flip, curve_inp_i);
            dmat2(end,1) = 10000000;
            M2 = min(dmat2, [], 'all');
            
            %M2_sum = M2_sum + M2
            %M2_sum(theta_ctr) =  M2;
            min_theta_val(i,1) = M2;
        end
        M2_sum = min(min_theta_val);
    end
    %   c = [dist_1-M1;
    %       M1-dist_2];
    
    c = dist_1-M1;
    
    
    ceq = [];
    
    
end












if const_case ==2
    
    original = 1;
    rotated = 0;
    [curve_o, ~] = plot_final(x, original, rotated);
    %[curve_m, ~] = plot_final(x1, original, rotated);
    curve_o = [0 0 0;curve_o];
    curve_flip = flipud(curve_o);
    
    % calculate an interpolated curve
    ctr = 0;
    for i =6:size(curve_o,1)-1
        j=0;
        P1 = curve_o(i,:);
        P2 = curve_o(i+1,:);
        n = 10;
        t = linspace(0,1,n)';
        P_inb = (1-t)*P1 + t*P2;
        P_inb = P_inb(2:end,:);
        if i==1
            j=0;
        end
        %     n*ctr+j:(ctr+1)*n-1
        %ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1)
        curve_inp(ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1),:) = P_inb;
        
        ctr = ctr+1;
        j=0;
    end
    curve_inp = [0 0 0;curve_inp];
    curve_flip_inp = flipud(curve_inp);
    
    curve_flip_inp(:,1) = -curve_flip_inp(:,1); % mirror about x
    curve_flip_inp(:,2) = curve_flip_inp(:,2);  % mirror about y
    curve_flip_inp(:,3) = -curve_flip_inp(:,3);
    
    
    %curve_uniq = unique(curve_inp,'rows');
    % specify what kind of mirror you want
    curve_flip(:,1) = -curve_flip(:,1); % mirror about x
    curve_flip(:,2) = curve_flip(:,2);  % mirror about y
    curve_flip(:,3) = -curve_flip(:,3);
    
    % Generate the whole knot
    curve_joined = [curve_flip;curve_o]; % the whole knot
    curve_joined_inp = [curve_flip_inp;curve_inp]; % the whole knot
    
    dmat1 = distmat(curve_flip, curve_o);
    dmat1(end,1) = 10000000;
    % M1 = min(dmat1, [], 'all');
    
    
    dmat1_inp = distmat(curve_flip_inp, curve_inp);
    dmat1_inp(end,1) = 10000000;
    M1 = min(dmat1_inp, [], 'all');
    %c1 = [0.0001 - M1];
    %ceq = [];
    
    %=================================================================
    seq = x;
    
    
    % check collision for each angle of bending
    theta_bend_max = bending_angle;
    sign = bending_angle/abs(bending_angle);
    theta_ctr = 0;
    min_theta_val = zeros(length(0:sign*1:theta_bend_max),1);
    for theta_i = 0:sign*1:theta_bend_max
        
        theta_bend = theta_i;
        theta_ctr = theta_ctr+1;
        theta_twist = twisting_angle;
        X=[0;0;0];
        R = eye(3,3);
        M2_sum =0;
        for i =1:size(seq,2)
            
            el = seq(i);
            if (el<1) && (el>0)
                el=1;
            end
            if (el<2) && (el>1)
                el=2;
            end
            if (el<3) && (el>2)
                el=3;
            end
            if (el<4) && (el>3)
                el=4;
            end
            if (el<5) && (el>4)
                el=5;
            end
            if (el<6) && (el>5)
                el=6;
            end
            if (el<7) && (el>6)
                el=7;
            end
            
            % positive bend around z axis
            if el==1
                alpha = 0;beta = 0; gamma = theta_bend;
            end
            
            % negative bend around z axis
            if el==2
                alpha = 0;beta = 0; gamma = -theta_bend;
            end
            
            % positive bend around y
            if el==3
                alpha = 0;beta = theta_bend; gamma = 0;
            end
            
            % negative bend around y
            if el==4
                alpha = 0;beta = -theta_bend; gamma = 0;
            end
            
            
            % neutral element
            if el==5
                alpha = 0;beta = 0; gamma = 0;
            end
            
            % positive twisting element
            if el==6
                alpha = theta_twist;beta = 0; gamma = 0;
            end
            
            % negative twisting element
            if el==7
                alpha = -theta_twist;beta = 0; gamma = 0;
            end
            
            alpha = alpha*pi/180;beta = beta*pi/180;gamma = gamma*pi/180;
            
            R_x = [1 0          0;
                0 cos(alpha) -sin(alpha);
                0 sin(alpha) cos(alpha)];
            
            R_y = [cos(beta) 0  sin(beta);
                0         1  0
                -sin(beta) 0  cos(beta)];
            
            
            R_z = [cos(gamma) -sin(gamma) 0;
                sin(gamma)  cos(gamma) 0;
                0           0          1];
            
            delta_x_val = (0.09890*L)/((bending_angle*pi)/180);
            delta_y_val = ((0.2472*L*180)/(bending_angle*pi))*(theta_i*pi/180);
            
            
            
            if el ==1
                delta_x = delta_x_val*(theta_i*pi/180)+L; delta_y= delta_y_val; delta_z=0;
            end
            if el ==2
                delta_x = delta_x_val*(theta_i*pi/180)+L ;delta_y= -delta_y_val; delta_z=0;
            end
            if el ==3
                delta_x = delta_x_val*(theta_i*pi/180)+L ; delta_y = 0; delta_z = delta_y_val;
            end
            if el ==4
                delta_x = delta_x_val*(theta_i*pi/180)+L; delta_y = 0; delta_z = -delta_y_val;
            end
            if el ==5
                delta_x = L;delta_y = 0;delta_z = 0;
            end
            if el ==6
                delta_x = L;delta_y = 0; delta_z = 0;
            end
            if el ==7
                delta_x = L;delta_y = 0; delta_z = 0;
            end
            delta_X = R*[delta_x;delta_y;delta_z];
            
            X = X + delta_X;
            
            R_curr = R_z*R_y*R_x;
            
            R = R*R_curr;
            P  = X;
            curve(i,:) = X';
            
            
            
            
            
            % if el ==1
            % delta_x = 1.09890*L; delta_y=0.2472*L; delta_z=0;
            % end
            % if el ==2
            %  delta_x = 1.09890*L ;delta_y= -0.2472*L;delta_z=0;
            % end
            % if el ==3
            %     delta_x = 1.09890*L ;delta_y = 0;delta_z = 0.2472*L;
            % end
            % if el ==4
            % delta_x = 1.09890*L;delta_y = 0; delta_z = -0.2472*L;
            % end
            % if el ==5
            % delta_x = L;delta_y = 0;delta_z = 0;
            % end
            % if el ==6
            % delta_x = L;delta_y = 0; delta_z = 0;
            % end
            % if el ==7
            % delta_x = L;delta_y = 0; delta_z = 0;
            % end
            %          delta_X = R*[delta_x;delta_y;delta_z];
            %          P0=X;
            %          X=X+delta_X;
            %          P=X;
            %          R_curr = R_z*R_y*R_x;
            %
            %          R = R*R_curr;
            %          %plot_links(P,P0,[],el,0)
            %          curve(i,:) = X';
        end
        % generate the interpolated curve
        
        ctr = 0;
        for i =6:size(curve,1)-1
            j=0;
            P1 = curve(i,:);
            P2 = curve(i+1,:);
            n = 10;
            t = linspace(0,1,n)';
            P_inb = (1-t)*P1 + t*P2;
            P_inb = P_inb(2:end,:);
            if i==1
                j=0;
            end
            %     n*ctr+j:(ctr+1)*n-1
            %ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1)
            curve_inp(ctr*n+j-(ctr-1):(ctr+1)*n-(ctr+1),:) = P_inb;
            
            ctr = ctr+1;
            j=0;
        end
        curve_inp = [0 0 0;curve_inp];
        
        curve_flip = flipud(curve_inp);
        
        % specify what kind of mirror you want
        curve_flip(:,1) = -curve_flip(:,1); % mirror about x
        curve_flip(:,2) = curve_flip(:,2);  % mirror about y
        curve_flip(:,3) = -curve_flip(:,3);
        
        % Generate the whole knot
        curve_joined = [curve_flip;curve_inp]; % the whole knot
        
        
        dmat2 = distmat(curve_flip, curve_inp);
        dmat2(end,1) = 10000000;
        M2 = min(dmat2, [], 'all');
        
        %M2_sum = M2_sum + M2
        %M2_sum(theta_ctr) =  M2;
        min_theta_val(theta_ctr,1) = M2;
    end
    M2_sum = min(min_theta_val);
    
    
    %c = [0.0001 - M];
    % c = [0.0001-M1;
    %      1.0-M2_sum];
    % c = [dist_1-M1_inp;
    %      dist_2-M2_sum];
    %tubeplot(curve_joined',1, 8, 1/2, 1, 2);daspect([1,1,1]); camlight;
    
    %  c = [dist_1-M1];
    
    c = [dist_1-M1;
        dist_2-M2_sum];
    
    %  c = [M1-dist_1;
    %      M2_sum-dist_2];
    
    ceq = [];
end
end
%========== calculate objective function ===================
function obj = obj_cal(p_error, q_error,fac)
obj = p_error+fac*q_error;
end

function [alpha, beta, gamma] = param(el)
global theta_twist theta_bend
% positive bend around z axis
if el==1
    alpha = 0;beta = 0; gamma = theta_bend;
end

% negative bend around z axis
if el==2
    alpha = 0;beta = 0; gamma = -theta_bend;
end

% positive bend around y
if el==3
    alpha = 0;beta = theta_bend; gamma = 0;
end

% negative bend around y
if el==4
    alpha = 0;beta = -theta_bend; gamma = 0;
end


% neutral element
if el==5
    alpha = 0;beta = 0; gamma = 0;
end

% positive twisting element
if el==6
    alpha = theta_twist;beta = 0; gamma = 0;
end

% negative twisting element
if el==7
    alpha = -theta_twist;beta = 0; gamma = 0;
end

alpha = alpha*pi/180;beta = beta*pi/180;gamma = gamma*pi/180;
end

function [curve] = geometry(seq, theta_bend, theta_twist)
global bending_angle twisting_angle L
theta_i = theta_bend;
X=[0;0;0];
R = eye(3,3);

for i =1:size(seq,2)
    
    el = seq(i);
    el = element_category(el);
    
    
    % positive bend around z axis
    if el==1
        alpha = 0;beta = 0; gamma = theta_bend;
    end
    
    % negative bend around z axis
    if el==2
        alpha = 0;beta = 0; gamma = -theta_bend;
    end
    
    % positive bend around y
    if el==3
        alpha = 0;beta = theta_bend; gamma = 0;
    end
    
    % negative bend around y
    if el==4
        alpha = 0;beta = -theta_bend; gamma = 0;
    end
    
    
    % neutral element
    if el==5
        alpha = 0;beta = 0; gamma = 0;
    end
    
    % positive twisting element
    if el==6
        alpha = theta_twist;beta = 0; gamma = 0;
    end
    
    % negative twisting element
    if el==7
        alpha = -theta_twist;beta = 0; gamma = 0;
    end
    
    alpha = alpha*pi/180;beta = beta*pi/180;gamma = gamma*pi/180;
    
    R_x = [1 0          0;
        0 cos(alpha) -sin(alpha);
        0 sin(alpha) cos(alpha)];
    
    R_y = [cos(beta) 0  sin(beta);
        0         1  0
        -sin(beta) 0  cos(beta)];
    
    
    R_z = [cos(gamma) -sin(gamma) 0;
        sin(gamma)  cos(gamma) 0;
        0           0          1];
    
    delta_x_val = (cos(bending_angle*0.0174533)*L)/((bending_angle*pi)/180);
    delta_y_val = ((sin(bending_angle*0.0174533)*L*180)/(bending_angle*pi))*(theta_i*pi/180);
    
    
    
    if el ==1
        delta_x = delta_x_val*(theta_i*pi/180)+L; delta_y= delta_y_val; delta_z=0;
    end
    if el ==2
        delta_x = delta_x_val*(theta_i*pi/180)+L ;delta_y= -delta_y_val; delta_z=0;
    end
    if el ==3
        delta_x = delta_x_val*(theta_i*pi/180)+L ; delta_y = 0; delta_z = delta_y_val;
    end
    if el ==4
        delta_x = delta_x_val*(theta_i*pi/180)+L; delta_y = 0; delta_z = -delta_y_val;
    end
    if el ==5
        delta_x = L;delta_y = 0;delta_z = 0;
    end
    if el ==6
        delta_x = L;delta_y = 0; delta_z = 0;
    end
    if el ==7
        delta_x = L;delta_y = 0; delta_z = 0;
    end
    delta_X = R*[delta_x;delta_y;delta_z];
    
    X = X + delta_X;
    
    R_curr = R_z*R_y*R_x;
    
    R = R*R_curr;
    P  = X;
    curve(i,:) = X';
    
end
end

function el = element_category(el)
if (el<1) && (el>0)
    el=1;
end
if (el<2) && (el>1)
    el=2;
end
if (el<3) && (el>2)
    el=3;
end
if (el<4) && (el>3)
    el=4;
end
if (el<5) && (el>4)
    el=5;
end
if (el<6) && (el>5)
    el=6;
end
if (el<7) && (el>6)
    el=7;
end
end


%%%%% Plots a rotated curve if required

function [curve_original, curve_rotated] = plot_final(x, original, rotated)

curve_original = [];
curve_rotated = [];
%R = eye(3,3);
if original ==1
    theta_base=0;
    R = [1 0          0;
        0 cos(theta_base) -sin(theta_base);
        0 sin(theta_base) cos(theta_base)];
    curve_original = comp_curve(R,x);
end
if rotated ==1
    theta_base=-1;
    R = [1 0          0;
        0 cos(theta_base) -sin(theta_base);
        0 sin(theta_base) cos(theta_base)];
    curve_rotated = comp_curve(R,x);
end





end

%%%% Function to calculate curve coordinates from element sequence
function curve = comp_curve(R,x)
global L theta_bend theta_twist val_delx val_dely val_delz
seq = x;
X=[0;0;0];
for i =1:size(seq,2)
    
    el = seq(i);
    if (el<1) && (el>0)
        el=1;
    end
    if (el<2) && (el>1)
        el=2;
    end
    if (el<3) && (el>2)
        el=3;
    end
    if (el<4) && (el>3)
        el=4;
    end
    if (el<5) && (el>4)
        el=5;
    end
    if (el<6) && (el>5)
        el=6;
    end
    if (el<7) && (el>6)
        el=7;
    end
    [alpha, beta, gamma] = param(el);
    R_x = [1 0          0;
        0 cos(alpha) -sin(alpha);
        0 sin(alpha) cos(alpha)];
    
    R_y = [cos(beta) 0  sin(beta);
        0         1  0
        -sin(beta) 0  cos(beta)];
    
    
    R_z = [cos(gamma) -sin(gamma) 0;
        sin(gamma)  cos(gamma) 0;
        0           0          1];
    
    if el ==1
        delta_x = 0.98*L; delta_y= 0.22*L; delta_z=0;
    end
    if el ==2
        delta_x = 0.98*L ;delta_y= -0.22*L;delta_z=0;
    end
    if el ==3
        delta_x = 0.98*L;delta_y = 0;delta_z = -0.22*L;
    end
    if el ==4
        delta_x = 0.98*L;delta_y = 0; delta_z = 0.22*L;
    end
    if el ==5
        delta_x = L;delta_y = 0;delta_z = 0;
    end
    if el ==6
        delta_x = L;delta_y = 0; delta_z = 0;
    end
    if el ==7
        delta_x = L;delta_y = 0; delta_z = 0;
    end
    
    delta_X = R*[delta_x;delta_y;delta_z];
    
    P0=X;
    X=X+delta_X;
    
    R_curr = R_z*R_y*R_x;
    
    R = R*R_curr;
    P=X;
    curve(i,:) = X';
end
end

%%%%% Function for plotting the knot
function [x,y,z]=tubeplot(curve,r,n,ct,itr, flag)
global video
global   x0 y0 z0 x_tip y_tip z_tip x_mid_gen y_mid_gen z_mid_gen x_mid y_mid z_mid
% Usage: [x,y,z]=tubeplot(curve,r,n,ct)
%
% Tubeplot constructs a tube, or warped cylinder, along
% any 3D curve, much like the build in cylinder function.
% If no output are requested, the tube is plotted.
% Otherwise, you can plot by using surf(x,y,z);
%
% Example of use:
% t=linspace(0,2*pi,50);
% tubeplot([cos(t);sin(t);0.2*(t-pi).^2],0.1);
% daspect([1,1,1]); camlight;
%
% Arguments:
% curve: [3,N] vector of curve data
% r      the radius of the tube
% n      number of points to use on circumference. Defaults to 8
% ct     threshold for collapsing points. Defaults to r/2
%
% The algorithms fails if you have bends beyond 90 degrees.
% Janus H. Wesenberg, july 2004
if nargin<3 || isempty(n), n=8;
    if nargin<2, error('Give at least curve and radius');
    end;
end;
if size(curve,1)~=3
    error('Malformed curve: should be [3,N]');
end;
if nargin<4 || isempty(ct)
    ct=0.5*r;
end

%Collapse points within 0.5 r of each other
npoints=1;
for k=2:(size(curve,2)-1)
    if norm(curve(:,k)-curve(:,npoints))>ct;
        npoints=npoints+1;
        curve(:,npoints)=curve(:,k);
    end
end
%Always include endpoint
if norm(curve(:,end)-curve(:,npoints))>0
    npoints=npoints+1;
    curve(:,npoints)=curve(:,end);
end
%deltavecs: average for internal points.
%           first strecth for endpoitns.
dv=curve(:,[2:end,end])-curve(:,[1,1:end-1]);
%make nvec not parallel to dv(:,1)
nvec=zeros(3,1);
[buf,idx]=min(abs(dv(:,1))); nvec(idx)=1;
xyz=repmat([0],[3,n+1,npoints+2]);

%precalculate cos and sing factors:
cfact=repmat(cos(linspace(0,2*pi,n+1)),[3,1]);
sfact=repmat(sin(linspace(0,2*pi,n+1)),[3,1]);

%Main loop: propagate the normal (nvec) along the tube
for k=1:npoints
    convec=cross(nvec,dv(:,k));
    convec=convec./norm(convec);
    nvec=cross(dv(:,k),convec);
    nvec=nvec./norm(nvec);
    %update xyz:
    xyz(:,:,k+1)=repmat(curve(:,k),[1,n+1])+...
        cfact.*repmat(r*nvec,[1,n+1])...
        +sfact.*repmat(r*convec,[1,n+1]);
end;

%finally, cap the ends:
xyz(:,:,1)=repmat(curve(:,1),[1,n+1]);
xyz(:,:,end)=repmat(curve(:,end),[1,n+1]);

%,extract results:
x=squeeze(xyz(1,:,:));
y=squeeze(xyz(2,:,:));
z=squeeze(xyz(3,:,:));

%... and plot:
if nargout<3,
    h= figure()
    %set(gca, 'position', [0 0 1 1])
    if flag==1
        surf(x,y,z,'FaceColor','r');daspect([1,1,1]); camlight;
    end
    hold on
    if flag==2
        surf(x,y,z,'FaceColor','w');daspect([1,1,1]); camlight;
        
        %       xlim([-130 130])
        %       ylim([-10 100])
        %       zlim([-10 10])
        
        
        
        %%%set(gca,'innerposition',[0 0 600 400]);
        %set(gcf,'position',[100,100,500,200])
        %set(gca, 'position', [-0.2 -0.2 1.2 1.5])
        %set(gcf,'Visible', 'off');
        axis on
        box off
        
        %    set(gcf, 'Position', get(0, 'Screensize'));
        
        %exportgraphics(h,'figure%d.png',itr,'Resolution',300)
        %     if ((itr<75) || (itr>82))
        %     currframe=getframe(gcf);
        %     writeVideo(video,currframe);
        %     end
        %saveas(h,sprintf('FIG%d.png',itr));
        
        %hold on
        %plot3(x0,y0,z0, 'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
        %text(x0,y0,z0,'\leftarrow anchor point #2', 'Color','k','FontSize',14,'FontWeight', 'bold')
        %hold on
        %plot3(x_tip,y_tip,z_tip,'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
        
        %hold on
        %plot3(x_mid,y_mid,z_mid,'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
        %text(x_mid+5,y_mid,z_mid,'\leftarrow anchor point #1','Color','k','FontSize',14,'FontWeight', 'bold')
        %hold on
        %plot3(x_mid_gen,y_mid_gen,z_mid_gen,'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
    end
    xlabel('x')
    
    ylabel('y')
    zlabel('z')
    set(gcf,'color','w');
    
    %view(0,90);
    saveas(h,sprintf('figure_super_knots%d.png',itr));
    
end;
hold off
end

%%%% Function to calculate distances between two points for the curves
function dmat = distmat(curve_1, curve_2)

for i = 1:size(curve_1,1)
    for j = 1:size(curve_2,1)
        
        dmat(i,j) = sqrt((curve_1(i,1)-curve_2(j,1))^2+(curve_1(i,2)-curve_2(j,2))^2+(curve_1(i,3)-curve_2(j,3))^2);
        
    end
end

end
 
