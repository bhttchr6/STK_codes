


% plot one sequence
function plot2curves
x1 =  [5 6 1 1 1 1 1 1 1 1 6 1 3 1];
x2 = [5 6 1 1 1 1 1 1 1 1 1 1 3];
%%% geenrate curve 1
curve1 = comp_curve(x1, 120/14, 26, 4);
curve_1 = [0 0 0;curve1];
curve_flip1 = flipud(curve_1);

% specify what kind of mirror you want
curve_flip1(:,1) = -curve_flip1(:,1); % mirror about x
curve_flip1(:,2) = curve_flip1(:,2);  % mirror about y
curve_flip1(:,3) = -curve_flip1(:,3);
curve_joined1 = [curve_flip1;curve1];


%%% geenrate curve 2
curve2 = comp_curve(x2, 120/13, 25, 4);
curve_2 = [0 0 0;curve2];
curve_flip2 = flipud(curve_2);

% specify what kind of mirror you want
curve_flip2(:,1) = -curve_flip2(:,1); % mirror about x
curve_flip2(:,2) = curve_flip2(:,2);  % mirror about y
curve_flip2(:,3) = -curve_flip2(:,3);
curve_joined2 = [curve_flip2;curve2];

 tubeplot_full(curve_joined2',curve_joined1', 1, 8, 1/2);daspect([1,1,1]);% camlight;

end

function curve = comp_curve(x, L, theta_bend, theta_twist)
 
seq = x;
    X=[0;0;0];
    R = eye(3,3);
    for i =1:size(seq,2)

     el = seq(i);   
     if (el<1) && (el>0) 
         el=1;
     end
     if (el<2) && (el>1) 
         el=2;
     end
     if (el<3) && (el>2) 
         el=3;
     end
     if (el<4) && (el>3) 
         el=4;
     end
     if (el<5) && (el>4) 
         el=5;
     end
     if (el<6) && (el>5) 
         el=6;
     end
     if (el<7) && (el>6) 
         el=7;
     end
     [alpha, beta, gamma] = param(el, theta_bend, theta_twist);
    R_x = [1 0          0;
           0 cos(alpha) -sin(alpha);
           0 sin(alpha) cos(alpha)];

    R_y = [cos(beta) 0  sin(beta);
           0         1  0
           -sin(beta) 0  cos(beta)];


    R_z = [cos(gamma) -sin(gamma) 0;
           sin(gamma)  cos(gamma) 0;
           0           0          1];

if el ==1
%  delta_x = cos(theta_bend*0.0174533)*L; delta_y= sin(theta_bend*0.0174533)*L; delta_z=0;
 delta_x = 0.98*L; delta_y = 0.22*L; delta_z = 0;
end
if el ==2
%   delta_x = cos(theta_bend*0.0174533)*L ;delta_y= -sin(theta_bend*0.0174533)*L;delta_z=0; 
 delta_x = 0.98*L; delta_y = -0.22*L; delta_z = 0;
end
if el ==3
%      delta_x = cos(theta_bend*0.0174533)*L ;delta_y = 0;delta_z = -sin(theta_bend*0.0174533)*L;
 delta_x = 0.98*L; delta_y = 0; delta_z = -0.22*L;
end
if el ==4
%  delta_x = cos(theta_bend*0.0174533)*L;delta_y = 0; delta_z = sin(theta_bend*0.0174533)*L;
 delta_x = 0.98*L; delta_y = 0; delta_z = 0.22*L;
end
if el ==5
 delta_x = L;delta_y = 0;delta_z = 0;
end
if el ==6
delta_x = L;delta_y = 0; delta_z = 0;
end
if el ==7
delta_x = L;delta_y = 0; delta_z = 0;
end
    
    delta_X = R*[delta_x;delta_y;delta_z];
    
    P0=X;
    X=X+delta_X;
    
    R_curr = R_z*R_y*R_x;

    R = R*R_curr;
    P=X;
    curve(i,:) = X';
    end
end

function [alpha, beta, gamma] = param(el, theta_bend, theta_twist)

% positive bend around z axis
     if el==1
         alpha = 0;beta = 0; gamma = theta_bend;
     end
 
 % negative bend around z axis    
     if el==2
         alpha = 0;beta = 0; gamma = -theta_bend;
     end
     
 % positive bend around y    
     if el==3
         alpha = 0;beta = theta_bend; gamma = 0;
     end
     
  % negative bend around y   
     if el==4
         alpha = 0;beta = -theta_bend; gamma = 0;
     end
     
     
  % neutral element   
     if el==5
         alpha = 0;beta = 0; gamma = 0;
     end
     
  % positive twisting element   
     if el==6
         alpha = theta_twist;beta = 0; gamma = 0;
     end
  
   % negative twisting element   
     if el==7
         alpha = -theta_twist;beta = 0; gamma = 0;
     end  
     
     alpha = alpha*pi/180;beta = beta*pi/180;gamma = gamma*pi/180;
end
