function check_coll(x)
global bending_angle twisting_angle L theta_bend theta_twist
for theta_i = 0:1:25
        n_var = 12; % no. of elements
     itr = theta_i+1;
     theta_twist = 4;
%       theta_bend = 25;
      theta_bend = theta_i;
      bending_angle = theta_bend;
    
     twisting_angle = theta_twist;
%x = [5 6 1 1 1 1 1 1 1 1 1 1 3];
numberOfVariables = size(x,2);
L_knot = 120; %cm
L = L_knot/numberOfVariables;
x1 = [x];
x2 = flip(x);
%fval
original =1;
rotated =0;
[curve_o, ~] = plot_final(x, original, rotated);
[curve_m, ~] = plot_final(x1, original, rotated);
curve_o = [0 0 0;curve_o];
curve_flip = flipud(curve_o);

% specify what kind of mirror you want
curve_flip(:,1) = -curve_flip(:,1); % mirror about x
curve_flip(:,2) = curve_flip(:,2);  % mirror about y
curve_flip(:,3) = -curve_flip(:,3);
curve_joined = [curve_flip;curve_m];
tubeplot(curve_joined',1, 8, 1/2, itr, 1);daspect([1,1,1]); 
end

end

function [curve_original, curve_rotated] = plot_final(x, original, rotated)

curve_original = [];
curve_rotated = [];
%R = eye(3,3);
if original ==1 
    theta_base=0;
    R = [1 0          0;
       0 cos(theta_base) -sin(theta_base);
       0 sin(theta_base) cos(theta_base)];
   curve_original = comp_curve(R,x);
end
if rotated ==1 
    theta_base=-1; 
    R = [1 0          0;
       0 cos(theta_base) -sin(theta_base);
       0 sin(theta_base) cos(theta_base)];
   curve_rotated = comp_curve(R,x);
end





end
function curve = comp_curve(R,x)
global L theta_bend theta_twist
seq = x;
    X=[0;0;0];
    for i =1:size(seq,2)

     el = seq(i);   
     if (el<1) && (el>0) 
         el=1;
     end
     if (el<2) && (el>1) 
         el=2;
     end
     if (el<3) && (el>2) 
         el=3;
     end
     if (el<4) && (el>3) 
         el=4;
     end
     if (el<5) && (el>4) 
         el=5;
     end
     if (el<6) && (el>5) 
         el=6;
     end
     if (el<7) && (el>6) 
         el=7;
     end
     [alpha, beta, gamma] = param(el);
    R_x = [1 0          0;
           0 cos(alpha) -sin(alpha);
           0 sin(alpha) cos(alpha)];

    R_y = [cos(beta) 0  sin(beta);
           0         1  0
           -sin(beta) 0  cos(beta)];


    R_z = [cos(gamma) -sin(gamma) 0;
           sin(gamma)  cos(gamma) 0;
           0           0          1];

if el ==1
%delta_x = cos(theta_bend*0.0174533)*L; delta_y= sin(theta_bend*0.0174533)*L; delta_z=0;
delta_x = -0.0008*L*theta_bend+L; delta_y = 0.0088*L*theta_bend; delta_z = 0;
end
if el ==2
 %delta_x = cos(theta_bend*0.0174533)*L ;delta_y= -sin(theta_bend*0.0174533)*L;delta_z=0;  
 delta_x = -0.0008*L*theta_bend+L; delta_y = -0.0088*L*theta_bend; delta_z = 0;
end
if el ==3
%     delta_x = cos(theta_bend*0.0174533)*L ;delta_y = 0;delta_z = -sin(theta_bend*0.0174533)*L;
delta_x = -0.0008*L*theta_bend+L; delta_y = 0; delta_z = -0.0088*L*theta_bend;
end
if el ==4
%delta_x = cos(theta_bend*0.0174533)*L;delta_y = 0; delta_z = sin(theta_bend*0.0174533)*L;
delta_x = -0.0008*L*theta_bend+L; delta_y = 0; delta_z = 0.0088*L*theta_bend;
end
if el ==5
delta_x = 1.065*L;delta_y = 0;delta_z = 0;
end
if el ==6
delta_x = 1.065*L;delta_y = 0; delta_z = 0;
end
if el ==7
delta_x = 1.065*L;delta_y = 0; delta_z = 0;
end
    
    delta_X = R*[delta_x;delta_y;delta_z];
    
    P0=X;
    X=X+delta_X;
    
    R_curr = R_z*R_y*R_x;

    R = R*R_curr;
    P=X;
    curve(i,:) = X';
    end
end
function [alpha, beta, gamma] = param(el)
global theta_twist theta_bend
% positive bend around z axis
     if el==1
         alpha = 0;beta = 0; gamma = theta_bend;
     end
 
 % negative bend around z axis    
     if el==2
         alpha = 0;beta = 0; gamma = -theta_bend;
     end
     
 % positive bend around y    
     if el==3
         alpha = 0;beta = theta_bend; gamma = 0;
     end
     
  % negative bend around y   
     if el==4
         alpha = 0;beta = -theta_bend; gamma = 0;
     end
     
     
  % neutral element   
     if el==5
         alpha = 0;beta = 0; gamma = 0;
     end
     
  % positive twisting element   
     if el==6
         alpha = theta_twist;beta = 0; gamma = 0;
     end
  
   % negative twisting element   
     if el==7
         alpha = -theta_twist;beta = 0; gamma = 0;
     end  
     
     alpha = alpha*pi/180;beta = beta*pi/180;gamma = gamma*pi/180;
end

function plot_links(P,P0,dim,el,flag)
% H=dim(2); W=dim(3);
x_0= P0(1,1); x_p=P(1,1); y_0=P0(2,1); y_p = P(2,1); z_0=P0(3,1); z_p=P(3,1);
% p0=P0(2:end,:);
% P_bar=[P(1) P(2)+H/2 P(3)-W/2 1;
%     P(1) P(2)-H/2 P(3)-W/2 1;
%     P(1) P(2)+H/2 P(3)+W/2 1;
%     P(1) P(2)-H/2 P(3)+W/2 1];
% a_xy = (y_p-(y_0/x_0)*x_p)/(x_p^2-x_0*x_p);
% 
% b_xy = (y_0/x_0)-(y_p*x_0-y_0*x_p)/(x_p^2-x_0*x_p);

line_color=LC(el);
F1=(-1)^(el+1)*y_p/3;
F2=(-1)^(el+1)*6;
F3=(-1)^(el+1)*4;
L=sqrt((x_p-x_0)^2+(y_p-y_0)^2);
x=linspace(x_0,x_p,100);
%y = F.*(x.^2).*(3*L-x);

y = F1*((x/x_p).^2).*(F2-F3*(x/x_p)+(x/x_p).^2);




% 
% z = zeros(100,1);
if flag ==0
figure(1)
plot3([x_0 x_p],[y_0 y_p],[z_0 z_p],line_color, 'LineWidth',2)
 hold on
plot3(0,0,0,'o','MarkerSize',5,'MarkerFaceColor',[0.5,0.5,0.5]);
 view =[30,30];
axis equal
title('Structure after optimization')
xlabel('x')
 ylabel('y')
 zlabel('z')
 set(gcf,'color','w');
end

if flag ==1
figure(2)
plot3([x_0 x_p],[y_0 y_p],[z_0 z_p],line_color, 'LineWidth',2)
 hold on
plot3(0,0,0,'o','MarkerSize',5,'MarkerFaceColor',[0.5,0.5,0.5]);
 view =[30,30];
axis equal
title('Structure after optimization')
xlabel('x')
 ylabel('y')
 zlabel('z')
 set(gcf,'color','w');
end


end

function line_color=LC(el)

     if el==1
         line_color='b';
     end
     if el==2
         line_color='y';
     end
     if el==3
         line_color='r';
     end
     if el==4
         line_color='k';
     end
     if el==5
         line_color='m';
     end
     if el==6
         line_color='c';
     end
     if el==7
         line_color='g';
     end
  
end
function [x,y,z]=tubeplot(curve,r,n,ct,itr, flag)
global video
global   x0 y0 z0 x_tip y_tip z_tip x_mid_gen y_mid_gen z_mid_gen x_mid y_mid z_mid
% Usage: [x,y,z]=tubeplot(curve,r,n,ct)
% 
% Tubeplot constructs a tube, or warped cylinder, along
% any 3D curve, much like the build in cylinder function.
% If no output are requested, the tube is plotted.
% Otherwise, you can plot by using surf(x,y,z);
%
% Example of use:
% t=linspace(0,2*pi,50);
% tubeplot([cos(t);sin(t);0.2*(t-pi).^2],0.1);
% daspect([1,1,1]); camlight;
%
% Arguments:
% curve: [3,N] vector of curve data
% r      the radius of the tube
% n      number of points to use on circumference. Defaults to 8
% ct     threshold for collapsing points. Defaults to r/2 
%
% The algorithms fails if you have bends beyond 90 degrees.
% Janus H. Wesenberg, july 2004
  if nargin<3 || isempty(n), n=8;
     if nargin<2, error('Give at least curve and radius');
    end;
  end;
  if size(curve,1)~=3
    error('Malformed curve: should be [3,N]');
  end;
  if nargin<4 || isempty(ct)
    ct=0.5*r;
  end
  
  %Collapse points within 0.5 r of each other
  npoints=1;
  for k=2:(size(curve,2)-1)
    if norm(curve(:,k)-curve(:,npoints))>ct;
      npoints=npoints+1;
      curve(:,npoints)=curve(:,k);
    end
  end
  %Always include endpoint
  if norm(curve(:,end)-curve(:,npoints))>0
    npoints=npoints+1;
    curve(:,npoints)=curve(:,end);
  end
  %deltavecs: average for internal points.
  %           first strecth for endpoitns.
  dv=curve(:,[2:end,end])-curve(:,[1,1:end-1]);
  %make nvec not parallel to dv(:,1)
  nvec=zeros(3,1);
  [buf,idx]=min(abs(dv(:,1))); nvec(idx)=1;
  xyz=repmat([0],[3,n+1,npoints+2]);
  
  %precalculate cos and sing factors:
  cfact=repmat(cos(linspace(0,2*pi,n+1)),[3,1]);
  sfact=repmat(sin(linspace(0,2*pi,n+1)),[3,1]);
  
  %Main loop: propagate the normal (nvec) along the tube
  for k=1:npoints
    convec=cross(nvec,dv(:,k));
    convec=convec./norm(convec);
    nvec=cross(dv(:,k),convec);
    nvec=nvec./norm(nvec);
    %update xyz:
    xyz(:,:,k+1)=repmat(curve(:,k),[1,n+1])+...
        cfact.*repmat(r*nvec,[1,n+1])...
        +sfact.*repmat(r*convec,[1,n+1]);
  end;
  
  %finally, cap the ends:
  xyz(:,:,1)=repmat(curve(:,1),[1,n+1]);
  xyz(:,:,end)=repmat(curve(:,end),[1,n+1]);
  
  %,extract results:
  x=squeeze(xyz(1,:,:));
  y=squeeze(xyz(2,:,:));
  z=squeeze(xyz(3,:,:));
  
  %... and plot:
  if nargout<3,
     h= figure()
      %set(gca, 'position', [0 0 1 1])
      if flag==1
      surf(x,y,z,'FaceColor','r');daspect([1,1,1]); camlight;
      end
      hold on
      if flag==2
      surf(x,y,z,'FaceColor','w');daspect([1,1,1]); camlight;
      
%       xlim([-130 130])
%       ylim([-10 100])
%       zlim([-10 10])

      
    
    %%%set(gca,'innerposition',[0 0 600 400]);
    %set(gcf,'position',[100,100,500,200])
    %set(gca, 'position', [-0.2 -0.2 1.2 1.5])
    %set(gcf,'Visible', 'off');
    axis on
    box off
    
%    set(gcf, 'Position', get(0, 'Screensize'));

    %exportgraphics(h,'figure%d.png',itr,'Resolution',300)
%     if ((itr<75) || (itr>82))
%     currframe=getframe(gcf);
%     writeVideo(video,currframe);
%     end
    %saveas(h,sprintf('FIG%d.png',itr));
    
    %hold on
    %plot3(x0,y0,z0, 'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
   %text(x0,y0,z0,'\leftarrow anchor point #2', 'Color','k','FontSize',14,'FontWeight', 'bold')
    %hold on
    %plot3(x_tip,y_tip,z_tip,'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
    
    %hold on
    %plot3(x_mid,y_mid,z_mid,'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
    %text(x_mid+5,y_mid,z_mid,'\leftarrow anchor point #1','Color','k','FontSize',14,'FontWeight', 'bold')
    %hold on
    %plot3(x_mid_gen,y_mid_gen,z_mid_gen,'o','MarkerSize',40,'MarkerEdgeColor','k','MarkerFaceColor',[1 1 0])
      end
    xlabel('x')
      
    ylabel('y')
    zlabel('z')
    set(gcf,'color','w');
      
    %view(0,90);
    saveas(h,sprintf('figure_super_knots%d.png',itr));
      
  end;
  hold off
end