function [x1,y1,z1, x2, y2, z2]=tubeplot_full(curve1, curve2,r,n,ct)
% Usage: [x,y,z]=tubeplot(curve,r,n,ct)
% 
% Tubeplot constructs a tube, or warped cylinder, along
% any 3D curve, much like the build in cylinder function.
% If no output are requested, the tube is plotted.
% Otherwise, you can plot by using surf(x,y,z);
%
% Example of use:
% t=linspace(0,2*pi,50);
% tubeplot([cos(t);sin(t);0.2*(t-pi).^2],0.1);
% daspect([1,1,1]); camlight;
%
% Arguments:
% curve: [3,N] vector of curve data
% r      the radius of the tube
% n      number of points to use on circumference. Defaults to 8
% ct     threshold for collapsing points. Defaults to r/2 
%
% The algorithms fails if you have bends beyond 90 degrees.
% Janus H. Wesenberg, july 2004
  if nargin<3 || isempty(n), n=8;
     if nargin<2, error('Give at least curve and radius');
    end;
  end;
  if size(curve1,1)~=3
    error('Malformed curve: should be [3,N]');
  end;
  if nargin<4 || isempty(ct)
    ct=0.5*r;
  end
  
  %Collapse points within 0.5 r of each other
  npoints=1;
  for k=2:(size(curve1,2)-1)
    if norm(curve1(:,k)-curve1(:,npoints))>ct;
      npoints=npoints+1;
      curve1(:,npoints)=curve1(:,k);
    end
  end
  %Always include endpoint
  if norm(curve1(:,end)-curve1(:,npoints))>0
    npoints=npoints+1;
    curve1(:,npoints)=curve1(:,end);
  end
  %deltavecs: average for internal points.
  %           first strecth for endpoitns.
  dv=curve1(:,[2:end,end])-curve1(:,[1,1:end-1]);
  %make nvec not parallel to dv(:,1)
  nvec=zeros(3,1);
  [buf,idx]=min(abs(dv(:,1))); nvec(idx)=1;
  xyz=repmat([0],[3,n+1,npoints+2]);
  
  %precalculate cos and sing factors:
  cfact=repmat(cos(linspace(0,2*pi,n+1)),[3,1]);
  sfact=repmat(sin(linspace(0,2*pi,n+1)),[3,1]);
  
  %Main loop: propagate the normal (nvec) along the tube
  for k=1:npoints
    convec=cross(nvec,dv(:,k));
    convec=convec./norm(convec);
    nvec=cross(dv(:,k),convec);
    nvec=nvec./norm(nvec);
    %update xyz:
    xyz(:,:,k+1)=repmat(curve1(:,k),[1,n+1])+...
        cfact.*repmat(r*nvec,[1,n+1])...
        +sfact.*repmat(r*convec,[1,n+1]);
  end;
  
  %finally, cap the ends:
  xyz(:,:,1)=repmat(curve1(:,1),[1,n+1]);
  xyz(:,:,end)=repmat(curve1(:,end),[1,n+1]);
  
  %,extract results:
  x1=squeeze(xyz(1,:,:));
  y1=squeeze(xyz(2,:,:));
  z1=squeeze(xyz(3,:,:));
  
  
  %%% for curve 2
  if nargin<3 || isempty(n), n=8;
     if nargin<2, error('Give at least curve and radius');
    end;
  end;
  if size(curve2,1)~=3
    error('Malformed curve: should be [3,N]');
  end;
  if nargin<4 || isempty(ct)
    ct=0.5*r;
  end
  
  %Collapse points within 0.5 r of each other
  npoints=1;
  for k=2:(size(curve2,2)-1)
    if norm(curve2(:,k)-curve2(:,npoints))>ct;
      npoints=npoints+1;
      curve2(:,npoints)=curve2(:,k);
    end
  end
  %Always include endpoint
  if norm(curve2(:,end)-curve2(:,npoints))>0
    npoints=npoints+1;
    curve2(:,npoints)=curve2(:,end);
  end
  %deltavecs: average for internal points.
  %           first strecth for endpoitns.
  dv=curve2(:,[2:end,end])-curve2(:,[1,1:end-1]);
  %make nvec not parallel to dv(:,1)
  nvec=zeros(3,1);
  [buf,idx]=min(abs(dv(:,1))); nvec(idx)=1;
  xyz=repmat([0],[3,n+1,npoints+2]);
  
  %precalculate cos and sing factors:
  cfact=repmat(cos(linspace(0,2*pi,n+1)),[3,1]);
  sfact=repmat(sin(linspace(0,2*pi,n+1)),[3,1]);
  
  %Main loop: propagate the normal (nvec) along the tube
  for k=1:npoints
    convec=cross(nvec,dv(:,k));
    convec=convec./norm(convec);
    nvec=cross(dv(:,k),convec);
    nvec=nvec./norm(nvec);
    %update xyz:
    xyz(:,:,k+1)=repmat(curve2(:,k),[1,n+1])+...
        cfact.*repmat(r*nvec,[1,n+1])...
        +sfact.*repmat(r*convec,[1,n+1]);
  end;
  
  %finally, cap the ends:
  xyz(:,:,1)=repmat(curve2(:,1),[1,n+1]);
  xyz(:,:,end)=repmat(curve2(:,end),[1,n+1]);
  
  %,extract results:
  x2=squeeze(xyz(1,:,:));
  y2=squeeze(xyz(2,:,:));
  z2=squeeze(xyz(3,:,:));
  
  
  %... and plot:
  if nargout<3, figure(); surf(x1,y1,z1, 'FaceColor','r');hold on;surf(x2,y2,z2, 'FaceColor','g'); axis on;xlabel('x');ylabel('y');zlabel('z'); end;
end