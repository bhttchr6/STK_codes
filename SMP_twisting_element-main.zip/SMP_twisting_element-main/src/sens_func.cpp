#include "petscvec.h"
#include <petscksp.h>
#include <petscmat.h>
#include <petscdm.h>
#include <petscis.h>
#include "petscdmda.h"
#include "petscviewer.h"
#include <petscsys.h>
 #include <petsc/private/vecscatterimpl.h>

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include<numeric>
#include<cmath>
#include"analysis.h"
#include<vector>
#include<time.h>
using namespace Eigen;
using Eigen::MatrixXd;
using Eigen::VectorXd;
using std::vector;
typedef Eigen::SparseMatrix<double> SpMat;
using std::pow;
#define ngp 2
#define ndof 3
#define ndim 3
#define Tmax 350
#define Tmin 330
#define Tg 340
#define plane_strain 1
#define plane_stress 0

#define GAUSS_POINTS   4
#define NSD   3

using namespace Eigen;
typedef Eigen::Map<MatrixXd,0,Eigen::Stride<1,3> > MatMap;
typedef Eigen::Map<Matrix<PetscScalar,Dynamic, Dynamic, RowMajor> > matMap;
typedef Eigen::Map<Matrix<PetscScalar,Dynamic, 1> > vecMap;


 
void df_du(DM elas_da, DM prop_da,PetscInt rank, PetscInt nelx, PetscInt nely,PetscInt nelz, PetscScalar delta_t,PetscScalar penal, Vec& xPhys, PetscInt step_num, PetscInt step_den,PetscScalar T, PetscScalar *T_hist,PetscInt iter, PetscInt iter_heat,Mat& DFDUcoup)
{

PetscInt         si, sj, sk, ei, ej,ek, nx, ny,nz,e=0,size_x, sizeg_x, sizeg_y, size_y,sizeg_z, size_z,ctr_x,ctr_y,ctr_z, xp_size, *blk;
DM               cdm, u_cda;
DMDACoor3d       ***local_coords;
Vec              coords,local_F,u_local, *u_local_hist,xp;
ElasticityDOF    ***ff;
MatStencil        s_u[24];
PetscErrorCode   ierr;
PetscScalar     *u_local_array, *xp_array,  **u_local_hist_array;




int nel=nelx*nely*nelz;

// GET TEMPERATURE DISTRIBUTION
VectorXd temp(iter+1);;
for(int i=0;i<iter+1;i++){
temp(i)=T_hist[i];
}

//temp(iter+1)=T_hist[iter];
//if (rank==0)std::cout<< iter<<std::endl;std::cout<< "*****"<<std::endl;std::cout<< temp<<std::endl;std::cout<< "*****"<<std::endl;


//GET ELEMENTAL DENSITY DISTRIBUTION
 DMCreateLocalVector(prop_da, &xp);
   ierr = DMGlobalToLocalBegin(prop_da, xPhys, INSERT_VALUES, xp); 
   ierr = DMGlobalToLocalEnd(prop_da, xPhys, INSERT_VALUES, xp); 
   VecGetArray(xp,&xp_array);
   VecGetLocalSize(xp,&xp_size); // get size of local density vector
    VectorXd rho(xp_size);
for(PetscInt i=0;i<xp_size;i++){
rho(i)=xp_array[i];
}
VecRestoreArray(xp, &xp_array);
//GET LOCAL COORDINATES VECTOR
   DMGetCoordinateDM(elas_da, &cdm);
   DMGetCoordinatesLocal(elas_da, &coords); // get local coordinates with ghost cells
   DMDAVecGetArray(cdm,coords,&local_coords);  // convert Vec coords into array/structure




//
//int nnodes=(nelx+1)*(nely+1);
//int neq=nnodes*2;
//int n_nodes_x=nelx+1;
//int n_nodes_y=nely+1;



// define other variables
VectorXd delta_phi_g(iter);
VectorXd k(iter);


MatrixXd H_r(6,6);
MatrixXd H_r_inv(6,6);
MatrixXd dHr_dx(6,6);

MatrixXd A_r(6,6);
MatrixXd dAr_dx(6,6);


MatrixXd B_r(6,6);
MatrixXd dBr_dx(6,6);

MatrixXd Kneq_r(6,6);
MatrixXd dKneqr_dx(6,6);

MatrixXd Keq_r(6,6);
MatrixXd dKeqr_dx(6,6);

double neta_r;
double dnetar_dx;

MatrixXd H_g(6,6);
MatrixXd H_g_inv(6,6);
MatrixXd dHg_dx(6,6);

MatrixXd A_g(6,6);
MatrixXd A_g_inv(6,6);
MatrixXd dAg_dx(6,6);


MatrixXd B_g(6,6);
MatrixXd dBg_dx(6,6);


MatrixXd Kneq_g(6,6);
MatrixXd dKneqg_dx(6,6);

MatrixXd Keq_g(6,6);
MatrixXd dKeqg_dx(6,6);

double neta_g;
double dnetag_dx;

MatrixXd I(6,6);

MatrixXd C(iter,6);

int int_pt=0;
int w=1;//weights

VectorXd gp(ngp);
 gp<<-0.577350269189626,0.577350269189626;// gauss quadrature points
double DET;
MatrixXd B(6,24);
//MatrixXd dFint_du(neq,neq);



I=MatrixXd::Identity(6,6);

MatrixXd out_coeff_eir(6,6);
MatrixXd out_coeff_eig(6,6);
MatrixXd out_coeff_eis(6,6);
MatrixXd out_coeff_ei(6,6);
MatrixXd out_coeff_eir_term2(6,6);



MatrixXd deirn_dern(6,6);
MatrixXd deign_dern(6,6);
MatrixXd dein_dern(6,6);
MatrixXd deisn_dern(6,6);
MatrixXd dC_dern(6,6);
MatrixXd deirn_dern_term2(6,6);	
MatrixXd dern_den(6,6);
MatrixXd dfint_dern(6,6);
MatrixXd dfint_den(6,6);
MatrixXd alphar(6,6);
MatrixXd in_coeff_eir(6,6);
MatrixXd in_coeff_eig(6,6);
MatrixXd C_star(6,6);
MatrixXd F_bar(6,6);
MatrixXd E_bar(6,6);
MatrixXd O_bar(6,6);
MatrixXd M_bar(6,6);
MatrixXd N_bar(6,6);
MatrixXd A_g_inv_B_r(6,6);
MatrixXd diB_r(6,6);
MatrixXd A_g_inv_B_g(6,6);

//GET MESH INFO
  DMDAGetElementsCorners(elas_da,&si,&sj,&sk);                   // w/o the ghost cells
  DMDAGetElementsSizes(elas_da, &nx,&ny,&nz);                    // gets the non-overlapping no. of nodes
  DMDAGetCorners(elas_da, NULL, NULL,NULL,&size_x,&size_y,&size_z); // gets values w/o including ghost cells
  DMDAGetGhostCorners(elas_da, NULL,NULL,NULL, &sizeg_x,&sizeg_y,&sizeg_z);




//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//										ELEMENTAL LOOP 


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ctr_z=0;
for (ek = sk; ek < sk+nz; ek++) {
	ctr_y=0;
	for (ej = sj; ej < sj+ny; ej++) {
	ctr_x=0;
    		for (ei = si; ei < si+nx; ei++) {

 PetscScalar el_coords[24];
 PetscScalar *dfintdu_array;
 PetscCalloc1(24*24, &dfintdu_array);  // allocate zeroed space
  matMap dfintdu(dfintdu_array, 24, 24);    // map eigen matrix to memory

// get coordinates for the element //
   el_coords[NSD*0+0] = local_coords[ek][ej][ei].x;  el_coords[NSD*0+1] = local_coords[ek][ej][ei].y; el_coords[NSD*0+2]= local_coords[ek][ej][ei].z;

   el_coords[NSD*1+0] = local_coords[ek][ej][ei+1].x; el_coords[NSD*1+1] = local_coords[ek][ej][ei+1].y; el_coords[NSD*1+2] = local_coords[ek][ej][ei+1].z;

   el_coords[NSD*2+0] = local_coords[ek][ej+1][ei+1].x;  el_coords[NSD*2+1] = local_coords[ek][ej+1][ei+1].y; el_coords[NSD*2+2] = local_coords[ek][ej+1][ei+1].z;

   el_coords[NSD*3+0] = local_coords[ek][ej+1][ei].x;    el_coords[NSD*3+1] = local_coords[ek][ej+1][ei].y; el_coords[NSD*3+2] = local_coords[ek][ej+1][ei].z;

el_coords[NSD*4+0] = local_coords[ek+1][ej][ei].x;    el_coords[NSD*4+1] = local_coords[ek+1][ej][ei].y; el_coords[NSD*4+2] = local_coords[ek+1][ej][ei].z;

el_coords[NSD*5+0] = local_coords[ek+1][ej][ei+1].x;    el_coords[NSD*5+1] = local_coords[ek+1][ej][ei+1].y; el_coords[NSD*5+2] = local_coords[ek+1][ej][ei+1].z;

el_coords[NSD*6+0] = local_coords[ek+1][ej+1][ei+1].x;    el_coords[NSD*6+1] = local_coords[ek+1][ej+1][ei+1].y; el_coords[NSD*6+2] = local_coords[ek+1][ej+1][ei+1].z;

el_coords[NSD*7+0] = local_coords[ek+1][ej+1][ei].x;    el_coords[NSD*7+1] = local_coords[ek+1][ej+1][ei].y; el_coords[NSD*7+2] = local_coords[ek+1][ej+1][ei].z;

//if(rank==0) printf("el_coords0[%f] el_coords1[%f] el_coords2[%f] el_coords3[%f] elcoords4[%f] elcoords5[%f] \n", el_coords[6], el_coords[7], el_coords[8], el_coords[9], el_coords[10], el_coords[11]);
 

 MatMap el_coords_eig(el_coords, 8,3);        // convert CCur from scalar to MatrixXd



//{std::cout<<e<<std::endl;}

    //          
int_pt=0;
	for(int kp=0;kp<ngp;kp++)
	{
		for(int ip=0;ip<ngp;ip++)
		{
			for(int jp=0;jp<ngp;jp++)
			{

//if(int_pt==1) std::cout<<e<<std::endl;
		std::vector <Eigen::MatrixXd> D_iter(iter);

		MatrixXd D(6,6);
		MatrixXd D_step(6,6);
		MatrixXd D_step_inv(6,6);
		MatrixXd D_step_den_inv(6,6);
		MatrixXd D_step_den(6,6);
		VectorXd K1(iter);
		K1=VectorXd::Zero(iter);
//	
		double eta=gp(ip);
		double psi=gp(jp);
		double mu=gp(kp);
		 int_pt=int_pt+1;

//if(int_pt==1)std::cout<<e<<std::endl;
		//double rho_e=rho(e);
		shapel(psi,eta, mu,el_coords_eig,DET,B, int_pt, e,iter);
		//shapel(psi,eta,Ccur,DET,B);

		int phase=1;
		param(phase,rho,penal,e,Keq_r,dKeqr_dx,Kneq_r,dKneqr_dx, neta_r,dnetar_dx,I, int_pt, iter);
		paracon(Keq_r,neta_r,delta_t, Kneq_r, I, H_r,A_r,B_r);

		phase=2;
		param(phase,rho,penal,e,Keq_g,dKeqg_dx,Kneq_g,dKneqg_dx, neta_g,dnetag_dx,I, int_pt, iter);
		paracon(Keq_g,neta_g,delta_t, Kneq_g, I, H_g,A_g,B_g);

		A_g_inv=A_g.inverse() ;               
H_r_inv=H_r.inverse();
H_g_inv=H_g.inverse();


double rho_e=rho(e);

		int eta_i_aux=15000;
		int eta_i_smp=10000;
		double eta_i=eta_i_smp+rho_e*(eta_i_aux-eta_i_smp);
		// aux and SMP material
		
		double c_1=2.76e-05;
		double q=3;
		double c_2=4;


		VectorXd phi_g_total(iter+1);
                VectorXd phi_g_1(iter+1);
                VectorXd phi_r_1(iter+1);
                VectorXd phi_g_2(iter+1);
                VectorXd phi_r_2(iter+1);

		// phi_g and phi_r for SMP1
		phi_g_1(0) = 1-(1/(1+c_1*pow((Tmax-temp(0)),c_2)));
		phi_r_1(0) = 1-phi_g_1(0);

		// phi_g and phi_r for SMP2
		double Tg2 = 345;
		phi_g_2(0) =  1-1/(1+exp(-0.66*(temp(0)-Tg2)));
		phi_r_2(0) = 1-phi_g_2(0);


		// phi_g mixture		
		phi_g_total(0) = phi_g_1(0)+rho_e*(phi_g_2(0)-phi_g_1(0));

		VectorXd phi_r_total(iter+1);
		phi_r_total(0)=1-phi_g_total(0);

	// loop over the iterations

		for(int i=0;i<iter;i++){
		
		// for SMP1
		phi_g_1(i+1) = 1-(1/(1+c_1*pow(Tmax-temp(i+1),c_2)));
		phi_r_1(i+1) = 1-phi_g_1(i+1);

		// for SMP2
		phi_g_2(i+1) = 1-1/(1+exp(-0.66*(temp(i+1)-Tg2)));
		phi_r_2(i+1) = 1-phi_g_2(i+1);

		// phi_g mixture
		phi_g_total(i+1) = phi_g_1(i+1)+ rho_e*(phi_g_2(i+1)-phi_g_1(i+1));
		phi_r_total(i+1)=1-phi_g_total(i+1);
		delta_phi_g(i)=phi_g_total(i+1)-phi_g_total(i);

		k(i)=1;
		if(temp(i+1)>temp(i)){
			K1(i)=1/(1-(delta_phi_g(i)/phi_g_total(i+1)));
		}  // if heating
		D=phi_r_total(i+1)*I+phi_g_total(i+1)*(A_g_inv*A_r)+(delta_t/eta_i)*A_r+delta_phi_g(i)*I;
                //D_iter.push_back(D);
                D_iter[i]=D;
		}//end of iter lopp

		int mark_num=step_num-1;
		int mark_den=step_den;

              


		 out_coeff_eir=-phi_g_total(iter)*(A_g_inv*B_r)+(delta_t/eta_i)*B_r;
		 out_coeff_eig=phi_g_total(iter)*(A_g_inv*B_g);
		 out_coeff_eis=-I;
	 	 out_coeff_ei=-I;




		if(step_num+1>=iter_heat){ out_coeff_eis=-K1(step_num)*I;}
		

		// define structure & variables
		alphar=((delta_t/neta_r)*(H_r_inv*Kneq_r));
		in_coeff_eir=H_r_inv*I;
		in_coeff_eig=(H_g_inv*I);
		C_star=(delta_t/neta_g)*(H_g_inv*Kneq_g);
		F_bar=A_g_inv*B_g;
		E_bar=-A_g_inv*B_r;
		O_bar=A_g_inv*A_r;
		M_bar=(delta_t/eta_i)*A_r;
		N_bar=-(delta_t/eta_i)*B_r;
		A_g_inv_B_r=A_g_inv*B_r;
		diB_r=(delta_t/eta_i)*B_r;
		A_g_inv_B_g=A_g_inv*B_g;
				
		all_const values;
		values.mark_den=mark_den;
                values.D_iter=D_iter;
		values.phi_g_total=phi_g_total;
		values.alphar=alphar;
		
		
		values.C_star=C_star;
		values.F_bar=F_bar;
		values.E_bar=E_bar;
		values.O_bar=O_bar;
		values.M_bar=M_bar;
		values.N_bar=N_bar;
		values.A_g_inv_B_r=A_g_inv_B_r;
		values.diB_r=diB_r;
		values.A_g_inv_B_g=A_g_inv_B_g;

		values.delta_phi_g=delta_phi_g;
		values.iter_heat=iter_heat;
		values.K1=K1;
//double tic=clock();		
                func_eir(out_coeff_eir, in_coeff_eir, in_coeff_eig,mark_num, values,deirn_dern);
		func_eig(out_coeff_eig, in_coeff_eir, in_coeff_eig, mark_num,values, deign_dern);
		func_ei(out_coeff_ei, in_coeff_eir, in_coeff_eig,mark_num,values, dein_dern);
		func_eis(out_coeff_eis,in_coeff_eir, in_coeff_eig ,mark_num,values,deisn_dern);



		dC_dern=deirn_dern+deign_dern+dein_dern+deisn_dern;
//if(rank==0){if(e==0){if(int_pt==1){if((step_num==1)&(step_den==0)){std::cout<<iter_heat<<std::endl;std::cout<<dC_dern<<std::endl;}}}}
//if(int_pt==1){std::cout<<e<<std::endl;std::cout<<dC_dern<<std::endl;}
		out_coeff_eir_term2=B_r;

		func_eir(out_coeff_eir_term2, in_coeff_eir, in_coeff_eig, mark_num,values, deirn_dern_term2);


//double toc=clock()-tic;
//double t_sens=((float)toc)/CLOCKS_PER_SEC;
//std::cout<< e << t_sens <<std::endl;
		D_step=D_iter[step_num];
		D_step_inv=D_step.inverse();

		D_step_den=D_iter[step_den];
		D_step_den_inv=D_step_den.inverse();

		dfint_dern=A_r*(D_step_inv*dC_dern)-deirn_dern_term2;

		dern_den=D_step_den_inv*I;

		dfint_den=dfint_dern*dern_den;

//if(rank==0){if(e==0){if(int_pt==1){std::cout<<iter_heat<<std::endl;std::cout<<dfint_den<<std::endl;}}}

//for(int i=0;i<ngp;i++)
//	{
//		for(int j=0;j<ngp;j++)
//		{
//		double eta=gp(i);
//		double psi=gp(j);
//		 int_pt=int_pt+1;
		
//		shapel(psi,eta,el_coords_eig,DET,B);      // call shape functions

		dfintdu+=B.transpose()*dfint_den*B*w*DET;
//if(rank==0){if(e==0){if(int_pt==1){std::cout<<iter_heat<<std::endl;std::cout<< dfint_den <<std::endl;}}}	   
		}// end of j loop
	}// end of i loop
}// end of k loop

//std::cout<<e<<std::endl;std::cout<< dfintdu <<std::endl;

		// displacement //
		  // node 0 //
	  s_u[0].i = ei;s_u[0].j = ej; s_u[0].k=ek;s_u[0].c = 0;          // Ux0 //
	  s_u[1].i = ei;s_u[1].j = ej; s_u[1].k=ek;s_u[1].c = 1;          // Uy0 //
          s_u[2].i = ei;s_u[2].j = ej; s_u[2].k=ek;s_u[2].c = 2;          //Uz0 //


	  // node 1 //
	  s_u[3].i = ei+1;s_u[3].j = ej; s_u[3].k = ek; s_u[3].c = 0;       // Ux1 //
	  s_u[4].i = ei+1;s_u[4].j = ej; s_u[4].k = ek; s_u[4].c = 1;        // Uy1 //
          s_u[5].i = ei+1;s_u[5].j = ej; s_u[5].k = ek; s_u[5].c = 2;        // Uz1 //


	  // node 2 //
	  s_u[6].i = ei+1;s_u[6].j = ej+1; s_u[6].k=ek; s_u[6].c = 0;      // Ux2 //
	  s_u[7].i = ei+1;s_u[7].j = ej+1; s_u[7].k = ek; s_u[7].c = 1;      // Uy2 //
	  s_u[8].i = ei+1;s_u[8].j = ej+1; s_u[8].k = ek; s_u[8].c = 2;      // Uz2 //


	  // node 3 //
	  s_u[9].i = ei;s_u[9].j = ej+1; s_u[9].k = ek;    s_u[9].c = 0;        // Ux3 //
	  s_u[10].i = ei;s_u[10].j = ej+1; s_u[10].k = ek; s_u[10].c = 1;        // Uy3 //
	  s_u[11].i = ei;s_u[11].j = ej+1; s_u[11].k = ek; s_u[11].c = 2;        // Uy3 //

          // node 4 //
	  s_u[12].i = ei;s_u[12].j = ej; s_u[12].k = ek+1; s_u[12].c = 0;        // Ux3 //
	  s_u[13].i = ei;s_u[13].j = ej; s_u[13].k = ek+1; s_u[13].c = 1;        // Uy3 //
	  s_u[14].i = ei;s_u[14].j = ej; s_u[14].k = ek+1; s_u[14].c = 2;        // Uy3 //

          // node 5 //
	  s_u[15].i = ei+1;s_u[15].j = ej; s_u[15].k = ek+1; s_u[15].c = 0;        // Ux3 //
	  s_u[16].i = ei+1;s_u[16].j = ej; s_u[16].k = ek+1; s_u[16].c = 1;        // Uy3 //
	  s_u[17].i = ei+1;s_u[17].j = ej; s_u[17].k = ek+1; s_u[17].c = 2;        // Uy3 //

          // node 6 //
	  s_u[18].i = ei+1;s_u[18].j = ej+1; s_u[18].k = ek+1; s_u[18].c = 0;        // Ux3 //
	  s_u[19].i = ei+1;s_u[19].j = ej+1; s_u[19].k = ek+1; s_u[19].c = 1;        // Uy3 //
	  s_u[20].i = ei+1;s_u[20].j = ej+1; s_u[20].k = ek+1; s_u[20].c = 2;        // Uy3 //

          // node 7 //
	  s_u[21].i = ei;s_u[21].j = ej+1; s_u[21].k = ek+1; s_u[21].c = 0;        // Ux3 //
	  s_u[22].i = ei;s_u[22].j = ej+1; s_u[22].k = ek+1; s_u[22].c = 1;        // Uy3 //
	  s_u[23].i = ei;s_u[23].j = ej+1; s_u[23].k = ek+1; s_u[23].c = 2;        // Uy3 //


// ==================================================================================================================assemble for all elements
       MatSetValuesStencil(DFDUcoup, 24, s_u, 24, s_u, dfintdu_array, ADD_VALUES);

PetscFree(dfintdu_array);
e=e+1;                                     // update the element number
ctr_x=ctr_x+1;

       }//end ei
ctr_y=ctr_y+1;
   }//end ej
ctr_z=ctr_z+1;
}

MatAssemblyBegin(DFDUcoup, MAT_FINAL_ASSEMBLY);
MatAssemblyEnd(DFDUcoup, MAT_FINAL_ASSEMBLY);
DMDAVecRestoreArray(cdm,coords,&local_coords);
//MatView(DFDUcoup, PETSC_VIEWER_STDOUT_WORLD);

VecDestroy(&xp);


}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//===================================================================================================================================================================================
void func_eir(MatrixXd &out_coeff_eir, MatrixXd &in_coeff_eir,MatrixXd &in_coeff_eig, int mark_num,  all_const &values,MatrixXd& val)
{


int mark_den;
mark_den=values.mark_den;

MatrixXd val_er(6,6);
//val_er=MatrixXd::Zero(3,3);

MatrixXd alphar;
alphar=values.alphar;

MatrixXd out_coeff_er(6,6);
out_coeff_er=out_coeff_eir*alphar;

func_er(out_coeff_er,in_coeff_eir, in_coeff_eig, mark_num,values, val_er);
MatrixXd val_eir(6,6);
val_eir=MatrixXd::Zero(6,6);

if(mark_num>mark_den){
	MatrixXd out_coeff_new(6,6);
	//out_coeff_new=MatrixXd::Zero(3,3);

	out_coeff_new=out_coeff_eir*in_coeff_eir;
	func_eir(out_coeff_new,in_coeff_eir, in_coeff_eig,mark_num-1,values, val_eir);

}

val=val_er+val_eir;
}




//====================================================================================================================================================================================================

void func_eig(MatrixXd &out_coeff_eig, MatrixXd &in_coeff_eir,MatrixXd &in_coeff_eig, int mark_num, all_const &values, MatrixXd& val)
{
MatrixXd C(6,6);
C=values.C_star;

int mark_den;
mark_den=values.mark_den;

MatrixXd out_coeff_new(6,6);
//out_coeff_new=MatrixXd::Zero(3,3);

out_coeff_new=out_coeff_eig*C;
//std::cout<< out_coeff_new <<std::endl;

//define prinmary output
MatrixXd val_1(6,6);
//val_1=MatrixXd::Zero(3,3);

func_eg(out_coeff_new, in_coeff_eir, in_coeff_eig,mark_num,values, val_1);

//define secondary output
MatrixXd val_out(6,6);
val_out=MatrixXd::Zero(6,6);
if(mark_num>mark_den){
	MatrixXd out_coeff_new_2(6,6);
	//out_coeff_new_2=MatrixXd::Zero(3,3);

	out_coeff_new_2=out_coeff_eig*in_coeff_eig;
	func_eig(out_coeff_new_2, in_coeff_eir, in_coeff_eig,mark_num-1,values, val_out);

}

val=val_out+val_1;

}

//====================================================================================================================================================================================================

void func_eg(MatrixXd &out_coeff_eg, MatrixXd &in_coeff_eir,MatrixXd &in_coeff_eig,int mark_num, all_const &values, MatrixXd& val)
{
MatrixXd F_bar(6,6);
F_bar=values.F_bar;

MatrixXd E_bar(6,6);
E_bar=values.E_bar;

MatrixXd O_bar(6,6);
O_bar=values.O_bar;

MatrixXd val_1(6,6);
val_1=MatrixXd::Zero(6,6);

MatrixXd val_2(6,6);
val_2=MatrixXd::Zero(6,6);

MatrixXd val_er(6,6);
val_er=MatrixXd::Zero(6,6);


int mark_den;
mark_den=values.mark_den;



if(mark_num>mark_den){
	MatrixXd out_coeff_1(6,6);
	//out_coeff_1=MatrixXd::Zero(3,3);

	MatrixXd out_coeff_2(6,6);
	//out_coeff_2=MatrixXd::Zero(3,3);

	out_coeff_1=out_coeff_eg*F_bar;
	out_coeff_2=out_coeff_eg*E_bar;

	func_eig(out_coeff_1, in_coeff_eir, in_coeff_eig,mark_num-1,values, val_1);
	func_eir(out_coeff_2,in_coeff_eir, in_coeff_eig, mark_num-1,values, val_2);

}
MatrixXd out_coeff_3(6,6);
//out_coeff_3=MatrixXd::Zero(3,3);

out_coeff_3=out_coeff_eg*O_bar;
func_er(out_coeff_3, in_coeff_eir, in_coeff_eig,mark_num,values, val_er);

val=val_er+val_1+val_2;
}//func end

//====================================================================================================================================================================================


void func_ei(MatrixXd &out_coeff_ei, MatrixXd &in_coeff_eir,MatrixXd &in_coeff_eig,int mark_num, all_const &values, MatrixXd& val)
{
double in_coeff_ei=1;

MatrixXd M_bar(6,6);
M_bar=values.M_bar;

MatrixXd N_bar(6,6);
N_bar=values.N_bar;

MatrixXd val_er(6,6);
val_er=MatrixXd::Zero(6,6);


int mark_den;
mark_den=values.mark_den;


MatrixXd out_coeff_er(6,6);
out_coeff_er=out_coeff_ei*M_bar;

func_er(out_coeff_er, in_coeff_eir, in_coeff_eig,mark_num,values, val_er);

MatrixXd val_1(6,6);
val_1=MatrixXd::Zero(6,6);

MatrixXd val_2(6,6);
val_2=MatrixXd::Zero(6,6);

if(mark_num>mark_den){
	MatrixXd out_coeff_1(6,6);
	//out_coeff_1=MatrixXd::Zero(3,3);

	MatrixXd out_coeff_2(6,6);
	//out_coeff_2=MatrixXd::Zero(3,3);

	out_coeff_1=out_coeff_ei*in_coeff_ei;
	out_coeff_2=out_coeff_ei*N_bar;

	func_ei(out_coeff_1, in_coeff_eir, in_coeff_eig,mark_num-1,values, val_1);
	func_eir(out_coeff_2, in_coeff_eir, in_coeff_eig, mark_num-1,values, val_2);

}

val=val_er+val_1+val_2;

}//func_end


//==================================================================================================================================================================================

void func_eis(MatrixXd &out_coeff_eis,MatrixXd &in_coeff_eir,MatrixXd &in_coeff_eig, int mark_num, all_const &values, MatrixXd& val)

{
val=MatrixXd::Zero(6,6);

int iter_heat;
iter_heat=values.iter_heat;

if(mark_num+1>=iter_heat){

       // std::cout<< mark_num<<std::endl;

      	MatrixXd I(6,6);
	I=MatrixXd::Identity(6,6);

	MatrixXd val_1(6,6);
	val_1=MatrixXd::Zero(6,6);
   
        VectorXd K;
        K=values.K1;
	
	MatrixXd in_coeff_eis(6,6);
	in_coeff_eis=K(mark_num)*I;

	MatrixXd out_coeff_1(6,6);
	//out_coeff_1=MatrixXd::Zero(3,3);

	out_coeff_1=out_coeff_eis*in_coeff_eis;
	func_eis(out_coeff_1,in_coeff_eir, in_coeff_eig, mark_num-1,values,val);
}


if(mark_num+1<iter_heat){
	MatrixXd val_1(6,6);
	MatrixXd in_coeff_eis(6,6);
	val_1=MatrixXd::Zero(6,6);

	MatrixXd I(6,6);
	I=MatrixXd::Identity(6,6);

	 in_coeff_eis=I;
	MatrixXd P_bar(6,6);
	//P_bar=MatrixXd::Zero(3,3);

	
	
        VectorXd delta_phi_g;
	delta_phi_g=values.delta_phi_g;

	int mark_den;
	mark_den=values.mark_den;        

        P_bar=delta_phi_g(mark_num)*I;

//if((mark_num==3) & (mark_den==3)) std::cout<<P_bar<<std::endl;


	MatrixXd val_er(6,6);
	val_er=MatrixXd::Zero(6,6);

	MatrixXd out_coeff_2(6,6);
	//out_coeff_2=MatrixXd::Zero(3,3);

	out_coeff_2=out_coeff_eis*P_bar;
        func_er(out_coeff_2, in_coeff_eir, in_coeff_eig,mark_num,values, val_er);

	

	if(mark_num>mark_den){
	MatrixXd out_coeff_1(6,6);
	//out_coeff_1=MatrixXd::Zero(3,3);
	
	out_coeff_1=out_coeff_eis*in_coeff_eis;
	func_eis(out_coeff_1,in_coeff_eir, in_coeff_eig, mark_num-1,values, val_1);
	}
	val=val_er+val_1;
        //std::cout<<"****mark_num****"<<mark_num<<"*****"<<std::endl;
       //std::cout<<"****val_Er ****"<<val_er<<"*****"<<std::endl;	
}

}// func end

//===========================================================================================================================================================================================

void func_er(MatrixXd &coeff_er, MatrixXd &in_coeff_eir,MatrixXd &in_coeff_eig,int mark_num, all_const &values, MatrixXd& val)
{
MatrixXd A(6,6);
//A=MatrixXd::Zero(3,3);

MatrixXd B(6,6);
//B=MatrixXd::Zero(3,3);

MatrixXd D_mark_num(6,6);

std::vector <Eigen::MatrixXd> D;
D=values.D_iter;


int mark_den;
mark_den=values.mark_den;

VectorXd phi_g_total;
phi_g_total=values.phi_g_total;



int iter_heat;
iter_heat=values.iter_heat;

VectorXd K;
K=values.K1;

MatrixXd A_g_inv_B_r(6,6);
MatrixXd A_g_inv_B_g(6,6);
MatrixXd diB_r(6,6);


A_g_inv_B_r=values.A_g_inv_B_r;
diB_r=values.diB_r;
A_g_inv_B_g=values.A_g_inv_B_g;

D_mark_num=D[mark_num];
MatrixXd D_mark_num_inv(6,6);

//double d_00=D_mark_num(0,0);
//double d_01=D_mark_num(0,1);
//double d_02=D_mark_num(0,2);
//double d_10=D_mark_num(1,0);
//double d_11=D_mark_num(1,1);
//double d_12=D_mark_num(1,2);
//double d_20=D_mark_num(2,0);
//double d_21=D_mark_num(2,1);
//double d_22=D_mark_num(2,2);

//double m_00=d_11*d_22-d_12*d_21;
//double m_01=d_10*d_22-d_12*d_20;
//double m_02=d_10*d_21-d_11*d_20;
//double m_10=d_01*d_22-d_02*d_21;
//double m_11=d_00*d_22-d_02*d_20;
//double m_12=d_00*d_21-d_01*d_20;
//double m_20=d_01*d_12-d_02*d_11;
//double m_21=d_00*d_12-d_02*d_10;
//double m_22=d_00*d_11-d_01*d_10;

//MatrixXd Coff(3,3);
//Coff<< m_00, -m_10, m_20,
  //     -m_01, m_11, -m_21,
  //     m_02, -m_12, m_22;

//double deter=d_00*(d_11*d_22-d_12*d_21)-d_01*(d_10*d_22-d_12*d_20)+d_02*(d_10*d_21-d_11*d_20);

//D_mark_num_inv=Coff/deter;
D_mark_num_inv=D_mark_num.inverse();

//D_mark_num_inv=D_mark_num.inverse();
A=D_mark_num_inv*(-phi_g_total(mark_num+1)*(A_g_inv_B_r)+diB_r);
B=D_mark_num_inv*(phi_g_total(mark_num+1)*(A_g_inv_B_g));


MatrixXd coeff_ei(6,6);
//coeff_ei=MatrixXd::Zero(3,3);

MatrixXd coeff_eis(6,6);
//coeff_eis=MatrixXd::Zero(3,3);

coeff_ei=-D_mark_num_inv;



coeff_eis=coeff_ei;


if(mark_num+1>=iter_heat){coeff_eis=K(mark_num)*coeff_ei;}

val=MatrixXd::Zero(6,6);

//if(mark_num<mark_den){std::cout<<val<<std::endl;}

if(mark_num==mark_den){val=coeff_er;}

if(mark_num>mark_den){
	MatrixXd out_coeff_1(6,6);
	//out_coeff_1=MatrixXd::Zero(3,3);

	MatrixXd out_coeff_2(6,6);
	//out_coeff_2=MatrixXd::Zero(3,3);

	MatrixXd out_coeff_3(6,6);
	//out_coeff_3=MatrixXd::Zero(3,3);

	MatrixXd out_coeff_4(6,6);
	//out_coeff_4=MatrixXd::Zero(3,3);

	MatrixXd val_1(6,6);
	//val_1=MatrixXd::Zero(3,3);

	MatrixXd val_2(6,6);
	//val_2=MatrixXd::Zero(3,3);

	MatrixXd val_3(6,6);
	//val_3=MatrixXd::Zero(3,3);

	MatrixXd val_4(6,6);
	//val_4=MatrixXd::Zero(3,3);

	out_coeff_1=coeff_er*A;
	out_coeff_2=coeff_er*B;
	out_coeff_3=coeff_er*coeff_ei;
	out_coeff_4=coeff_er*coeff_eis;


        func_eir(out_coeff_1, in_coeff_eir, in_coeff_eig, mark_num-1,values, val_1);
	func_eig(out_coeff_2, in_coeff_eir, in_coeff_eig, mark_num-1,values, val_2);
	func_ei(out_coeff_3,  in_coeff_eir, in_coeff_eig, mark_num-1,values, val_3);
	func_eis(out_coeff_4, in_coeff_eir, in_coeff_eig, mark_num-1,values, val_4);


	val=val_1+val_2+val_3+val_4;

}

}//end of func











