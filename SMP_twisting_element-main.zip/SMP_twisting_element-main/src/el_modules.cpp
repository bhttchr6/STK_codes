#include <Eigen/Dense>
#include <Eigen/Sparse>
 #include "petscvec.h"
#include <petscksp.h>
#include <petscmat.h>
#include <petscdm.h>
#include <petscis.h>
#include "petscdmda.h"
#include "petscviewer.h"
#include <petscsys.h>
 #include <petsc/private/vecscatterimpl.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include"analysis.h"


using Eigen::MatrixXd;
using Eigen::VectorXd;
using std::vector;
using Eigen::IOFormat;
typedef Eigen::SparseMatrix<double> SpMat;

void shapel(double psi, double eta, double mu, MatrixXd C, double& DET, MatrixXd& B, PetscInt int_pt, PetscInt e, PetscInt iter)
{
/*
%********************************************************************
% Compute shape function, derivatives, and determinant of hexahedral element
...SHAPEL gives three things in return,
    %********************************************************************
*/
IOFormat HeavyFmt(Eigen::FullPrecision, 0, ", ", ";\n","[","]","[","]");

 MatrixXd XNODE(3, 8);
 MatrixXd GN(3,8);
 MatrixXd J(3,3);
 MatrixXd Jinv(3,3);
 VectorXd XI(3);
 VectorXd XP_row(8);
 VectorXd YP_row(8);
 VectorXd ZP_row(8);
 VectorXd XI0(3);
 VectorXd SF;
 VectorXd DSF_1;
 VectorXd DSF_2;
 VectorXd DSF_3;

 MatrixXd DSF(3,8);
 MatrixXd GJ(3,3);
 MatrixXd GJINV(3,3);
 MatrixXd GDSF(3,8);





XI << psi, eta, mu;
XNODE << -1, 1, 1, -1, -1, 1, 1, -1,
	 -1, -1, 1, 1, -1, -1, 1, 1,
	 -1, -1, -1, -1, 1, 1, 1, 1;


for(int i=0;i<8;i++){

 XP_row = XNODE.row(0);
 YP_row = XNODE.row(1);
 ZP_row = XNODE.row(2);



XI0 << 1+XI(0)*XP_row(i), 1+XI(1)*YP_row(i), 1+XI(2)*ZP_row(i);
SF.conservativeResize(i+1);
DSF_1.conservativeResize(i+1);
DSF_2.conservativeResize(i+1);
DSF_3.conservativeResize(i+1);

PetscScalar val1, val2, val3;

val1=XI0(0);val2=XI0(1);val3=XI0(2); 
SF(i)    = 0.125*val1*val2*val3;
DSF_1(i) = 0.125*XP_row(i)*val2*val3;
DSF_2(i) = 0.125*YP_row(i)*val1*val3;
DSF_3(i) = 0.125*ZP_row(i)*val1*val2;

//if(i==0){if(int_pt==1){if(e==0){ std::cout<<XP_row(1)<<std::endl;}}}

}

DSF.row(0) = DSF_1;
DSF.row(1) = DSF_2;
DSF.row(2) = DSF_3;

GJ = DSF*C;
DET = GJ.determinant();
GJINV = GJ.inverse();
GDSF  = GJINV*DSF;

//B = kron(GDSF.transpose(), MatrixXd::Identity(3,3));
//if(int_pt==1){if(e==0){ std::cout<<GDSF<<std::endl;}}
VectorXd GDSF_1 = GDSF.row(0); VectorXd GDSF_2=GDSF.row(1); VectorXd GDSF_3 = GDSF.row(2);
B << GDSF_1(0),0,0,GDSF_1(1),0,0,GDSF_1(2),0,0,GDSF_1(3),0,0,GDSF_1(4),0,0,GDSF_1(5),0,0,GDSF_1(6),0,0,GDSF_1(7),0,0,
     0,GDSF_2(0),0,0,GDSF_2(1),0,0,GDSF_2(2),0,0,GDSF_2(3),0,0,GDSF_2(4),0,0,GDSF_2(5),0,0,GDSF_2(6),0,0,GDSF_2(7),0,
     0,0,GDSF_3(0),0,0,GDSF_3(1),0,0,GDSF_3(2),0,0,GDSF_3(3),0,0,GDSF_3(4),0,0,GDSF_3(5),0,0,GDSF_3(6),0,0,GDSF_3(7),
     GDSF_2(0),GDSF_1(0),0,GDSF_2(1),GDSF_1(1),0,GDSF_2(2),GDSF_1(2),0,GDSF_2(3),GDSF_1(3),0,GDSF_2(4),GDSF_1(4),0,GDSF_2(5),GDSF_1(5),0,GDSF_2(6),GDSF_1(6),0,GDSF_2(7),GDSF_1(7),0,
    0,GDSF_3(0),GDSF_2(0),0,GDSF_3(1),GDSF_2(1),0,GDSF_3(2),GDSF_2(2),0,GDSF_3(3),GDSF_2(3),0,GDSF_3(4),GDSF_2(4),0,GDSF_3(5),GDSF_2(5),0,GDSF_3(6),GDSF_2(6),0,GDSF_3(7),GDSF_2(7),
    GDSF_3(0),0,GDSF_1(0),GDSF_3(1),0,GDSF_1(1),GDSF_3(2),0,GDSF_1(2),GDSF_3(3),0,GDSF_1(3),GDSF_3(4),0,GDSF_1(4),GDSF_3(5),0,GDSF_1(5),GDSF_3(6),0,GDSF_1(6),GDSF_3(7),0,GDSF_1(7);

//if(int_pt==1){if(e==0){ std::cout<<B.cols()<<std::endl;}}

/*
GN  <<        (1 - xi) * (1 - eta) * (1 - mu),
             (1 + xi) * (1 - eta) * (1 - mu),
             (1 + xi) * (1 + eta) * (1 - mu),
             (1 - xi) * (1 + eta) * (1 - mu),
             (1 - xi) * (1 - eta) * (1 + mu),
             (1 + xi) * (1 - eta) * (1 + mu),
             (1 + xi) * (1 + eta) * (1 + mu),
             (1 - xi) * (1 + eta) * (1 + mu);
        GN *= 0.125;
GN<< eta-1, 1-eta, 1+eta, -eta-1,
     psi-1, -psi-1,1+psi, 1-psi;
GN=0.25*GN;
     

J=GN*C;

DET=J.determinant();

Jinv=J.inverse();

BB=Jinv*GN;

 double B1x     = BB(0,0);
 double B2x     = BB(0,1);
 double B3x     = BB(0,2);
 double B4x     = BB(0,3);
 double B1y     = BB(1,0);
 double B2y     = BB(1,1);
 double B3y     = BB(1,2);
 double B4y     = BB(1,3);

B<< B1x,  0,   B2x, 0,   B3x, 0,   B4x, 0,
    0,    B1y, 0,   B2y, 0,   B3y, 0,   B4y,
    B1y,  B1x,  B2y,  B2x, B3y,  B3x, B4y, B4x;

*/
//if(int_pt==1){if(e==29){if(iter==5){std::cout<<B.format(HeavyFmt)<<std::endl;} } }

}



//============================================================================================================
MatrixXd kron(MatrixXd A, MatrixXd B)
{
    int rowA = A.rows();
    int rowB = B.rows();
    int colA = A.cols();
    int colB = B.cols();

    MatrixXd ans(rowA*rowB, colA*colB);
    for(int i = 0; i < rowA; i++)
    {
        for(int j = 0; j < colA; j++)
        {
            ans.block(i*rowB, j*colB, rowB, colB) = A(i, j) * B;
        }
    }

    return ans;
}
